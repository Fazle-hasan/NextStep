# NextStep – Course Platform & Career Guidance Data Package

Data dictionary, verification and consent rules, and import instructions for the two datasets built for the NextStep Community Education & Career Development features. Build date: **2026-10-03**.

## 1. Files

| File | What it is | Rows |
|---|---|---|
| `course_platform_database.csv` | Course discovery dataset (requested deliverable 1) | 9,887 |
| `career_guidance_database.csv` | **Production** professional network – real, consented profiles only (requested deliverable 2) | 0 (header only – see §6) |
| `career_guidance_sample_database.csv` | Synthetic test profiles for development; same columns as production | 300 |
| `course_source_map.csv` | Provenance side-table: provider course ID, canonical URL, link-check result, pricing/run notes (1:1 with courses via `course_id`) | 9,887 |
| `excluded_broken_links.csv` | Courses dropped because their page returned HTTP 404 | 23 |
| `schema.sql` | PostgreSQL DDL for all tables, a public-directory view and consent/sample guard constraints | – |
| `validation_report.md` / `validation_results.json` | Automated validation output | – |
| `scripts/` | `build_courses.py`, `build_career.py`, `validate.py` – reproducible build and checks | – |

**Repository compatibility.** `https://github.com/Fazle-hasan/NextStep` returned 404 publicly and GitHub access is not linked to this session, so the repository's stack, schema and import conventions could not be reviewed. The files therefore follow generic, import-friendly conventions (snake_case headers identical to the requested schema, UTF-8, RFC 4180 quoting, ISO dates, `true`/`false`, PostgreSQL DDL provided). Map them onto the app's ORM models once the repository is accessible; no repository files were modified.

## 2. Conventions (both datasets)

- UTF-8, one header row, one record per row, comma-separated, RFC 4180 double-quote escaping, `\n` line endings, no embedded newlines.
- Column names are exactly those in the brief, in the brief's order.
- **Dates** `YYYY-MM-DD` (ISO 8601). SWAYAM run dates are converted to the Indian calendar date (source timestamps are 18:30 UTC = 00:00 IST).
- **Booleans** `true` / `false`. **Empty = not known / not stated by the source.** An empty boolean never means `false`.
- **Missing values**: always an empty field. No `N/A`, `NA`, `nil`, `-`, `not available` anywhere (checked automatically). The literal `unknown` is used **only** as a controlled value in classification fields (`pricing_type`, `hiring_status`, `community_affiliation_status`) where the field is mandatory.
- **Multi-value fields** (skills, roles, languages, topics…) are one text field with items separated by `"; "`.
- **Numbers** are plain numerics (no currency symbols, no ranges). Fees are only filled when verified; currency is ISO 4217 and required whenever a fee is > 0.

## 3. Course dataset – `course_platform_database.csv`

### 3.1 Column dictionary

R = required (never empty). Types: `text`, `int`, `num`, `bool`, `date`, `url`, `enum` (see §3.2).

| Column | Type | R | Purpose / rule |
|---|---|---|---|
| course_id | text | R | Stable primary key `CRS-` + 12 hex chars of SHA-1(`data_source` + provider course ID). Re-running the build gives the same ID for the same provider course. |
| course_name | text | R | Title exactly as published by the provider (NPTEL `NOC:` prefix removed). Microsoft partner-led courses append the course code. |
| course_slug | text | R | URL-safe unique slug from the title; collisions get a provider suffix (`-nptel`, `-coursera-2`). |
| course_description | text | | Provider summary, HTML stripped, truncated at a word boundary (≈220–400 chars, ends with `…`). NPTEL has no public summary: a factual description is generated from catalogue metadata (format, discipline, institute, instructor, number of units/lessons) – flagged in `course_source_map.notes`. |
| domain | enum | R | NextStep domain (§3.2), assigned by keyword rules on the title with the provider's own category as fallback. |
| sub_domain | text | R | Provider category (Coursera subdomain, NPTEL discipline, SWAYAM category, Microsoft content type). |
| subject | text | | Provider subject/product/industry tag. |
| skills_taught | text | | Microsoft products covered (from the catalogue). Left empty when the provider does not publish skills. |
| prerequisites | text | | Not published in any source catalogue used – empty. |
| target_audience | text | | Microsoft roles or SWAYAM programme alignment (e.g. `B.A., M.A.`). |
| difficulty_level | enum | | `beginner`, `intermediate`, `advanced`, `mixed` (only Microsoft publishes levels). |
| course_duration / duration_unit | num / enum | | Only when unambiguous: Microsoft minutes/hours, SWAYAM weeks, NPTEL weeks (when the outline is week-based), Coursera workload text when it parses cleanly (ranges are left empty; raw text kept in the source map). Both or neither are filled. |
| estimated_study_hours | num | | Derived only from explicit figures (minutes ÷ 60, or weeks × a single hours-per-week value). |
| learning_mode | enum | | `online_self_paced`, `online_cohort` (scheduled SWAYAM run), `instructor_led`, `hybrid`, `in_person`. |
| course_language | text | | ISO 639-1 codes, `; `-separated when several. NPTEL archive language is not published – empty unless the title states it or the matching SWAYAM run does. |
| course_format | enum | | `video_lectures`, `web_text_modules`, `interactive_modules`, `interactive_coding`, `guided_project` (Coursera page resolves to `/projects/`), `hands_on_lab`, `mixed`. |
| syllabus_or_curriculum_url | url | | Page that lists the curriculum (NPTEL course page, Microsoft path/cert page, freeCodeCamp curriculum). |
| learning_outcomes, practical_projects | text | | Not available from the catalogues used – empty (never invented). |
| course_materials_available | bool | | `true` when materials are openly viewable (NPTEL, Microsoft Learn paths, freeCodeCamp). |
| provider_name | text | R | Platform: `Coursera`, `Microsoft Learn`, `Microsoft` (certifications), `NPTEL`, `SWAYAM`, `freeCodeCamp`. The teaching institution is in `certificate_issuing_organization` and `course_source_map.offering_partner`. |
| provider_type | enum | R | `mooc_platform`, `technology_company`, `university`, `university_consortium`, `government_body`, `nonprofit`, `professional_body`, `training_company`. |
| instructor_name | text | | Instructor names as published by the provider (Coursera instructors API, NPTEL/SWAYAM catalogues). Never inferred. |
| course_url | url | R | Canonical course page (after following Coursera redirects). Unique. |
| enrollment_url | url | | Where to enrol – the current SWAYAM run for NPTEL courses that have one. |
| enrollment_status | enum | | `open`, `closed`, `upcoming`, `archived`. Only SWAYAM publishes this (`openForRegistration`); Microsoft paths and freeCodeCamp are always open. |
| course_start_date / course_end_date | date | | SWAYAM run dates only. |
| self_paced | bool | | |
| batch_availability | text | | Run information (SWAYAM enrolment close date, Microsoft partner scheduling). |
| pricing_type | enum | R | `free`, `paid`, `freemium`, `free_audit`, `subscription`, `financial_aid_available`, `unknown`. Coursera is `unknown` because audit/purchase/Coursera Plus/financial-aid options vary by course and country and were not verified per course. |
| course_fee | num | | `0` for verified-free learning (Microsoft Learn paths, NPTEL, SWAYAM, freeCodeCamp). Empty when the fee is not verified. |
| currency | text | | ISO 4217 – required whenever a fee > 0 (none recorded in this release). |
| free_certificate_available | bool | | `true` for freeCodeCamp certifications; `false` for NPTEL runs (certificate requires the paid proctored exam). |
| financial_aid_available, financial_aid_url, scholarship_available, scholarship_url, accessibility_features | | | Not verified per course – empty. |
| certificate_available | bool | | From the source: Coursera `VerifiedCert`, SWAYAM exam listed, Microsoft certification/credential, freeCodeCamp certification. `false` for Microsoft Learn paths (they award achievements, not certificates). |
| certificate_type | enum | | `certificate_of_completion` (provider-issued), `professional_certification` (requires a separate exam), `skills_credential` (Microsoft Applied Skills assessment), `academic_credit`, `none`. |
| certificate_issuing_organization | text | | Partner + platform (e.g. `Stanford Online; Coursera`), `IIT Madras (NPTEL)`, `Microsoft`. |
| certificate_fee | num | | Only when verified (`0` for freeCodeCamp). |
| examination_available | bool | | |
| examination_type | enum | | `final_exam`, `certification_exam`, `lab_based_assessment`, `quizzes_only`. |
| examination_mode | enum | | `in_person_proctored` (NPTEL), `online_proctored`, `online_unproctored`, `online_or_test_centre`. |
| examination_duration_minutes, passing_percentage, number_of_assessments | num | | Not verified per course – empty. |
| final_project_required | bool | | Coursera capstones; freeCodeCamp certifications whose description requires projects. |
| proctored_exam | bool | | |
| exam_registration_url | url | | Microsoft exam page, SWAYAM run page. |
| relevant_job_roles | text | | Microsoft job roles from the catalogue. |
| career_relevance | text | | Sourced links only: Microsoft certification study-guide membership / exam alignment; Coursera Specialization membership. |
| industry_recognition | text | | Never claimed – empty. |
| accreditation_details | text | | SWAYAM academic credits as listed by SWAYAM. |
| continuing_education_credits | num | | SWAYAM credits. |
| portfolio_value | enum | | `high`/`medium`/`low` – only set where projects are required. |
| course_rating / rating_source / rating_count | num / enum / int | | Only provider-published ratings (Microsoft Learn); never estimated. |
| official_source_url | url | R | Official page the record was verified against. |
| verification_status | enum | R | See §5.1. |
| last_verified_date | date | | Date the URL was link-checked. |
| data_source | enum | R | `coursera_catalog_api`, `microsoft_learn_catalog_api`, `nptel_course_catalog`, `swayam_course_explorer`, `freecodecamp_github_curriculum`. |
| record_created_date / record_updated_date | date | R | |

### 3.2 Domain vocabulary (`domain`)

`computer_science_software_engineering`, `data_analytics_business_intelligence`, `artificial_intelligence_machine_learning`, `generative_ai_data_science`, `cloud_computing_devops`, `cybersecurity_networking`, `web_mobile_development`, `database_sql_data_engineering`, `ui_ux_product_management`, `business_analysis_project_management`, `finance_accounting_banking`, `marketing_digital_marketing`, `human_resources_talent_acquisition`, `communication_english_language`, `entrepreneurship_business_development`, `teaching_education_instructional_design`, `government_competitive_exam_preparation`, `healthcare_administration_allied_health`, `vocational_technical_skills`, `freelancing_remote_work`, `professional_certifications`, `personal_development_workplace_skills`, plus additional domains supported by the sources: `business_management_leadership`, `engineering_core`, `science_mathematics`, `humanities_social_sciences`, `law_legal_studies`, `arts_design_media`, `agriculture_environment_sustainability`, `languages_other`.

Domain is a NextStep classification (not a provider claim). It is rule-based, so a small share of titles will be mis-filed; correct them in the app's admin UI or adjust `RULES` in `build_courses.py`.

## 4. Career guidance datasets

Production (`career_guidance_database.csv`) and sample (`career_guidance_sample_database.csv`) share one schema (exact column order from the brief).

### 4.1 Column dictionary

PII = personal information. **SC** = special-category data (religious affiliation) – never public without explicit, recorded consent.

| Group | Column | Type | R | PII | Notes |
|---|---|---|---|---|---|
| Identity | professional_id | text | R | | `PRO-` + UUID for real profiles; `PRO-SAMPLE-0001…` for samples. |
| | profile_type | enum | R | | `real`, `sample`. |
| | profile_status | enum | R | | `active`, `inactive`, `pending_review`, `suspended`, `withdrawn`, `sample_only`. |
| | full_name, preferred_name | text | R/ | PII | As submitted by the professional. Samples are named `Sample Professional NNNN`. |
| | professional_headline, professional_bio | text | | PII | Written or approved by the professional. |
| | profile_photo_url, public_profile_url, linkedin_url, portfolio_url, personal_website | url | | PII | Only links the professional supplied and agreed to publish. |
| | professional_email, professional_phone | text | | PII | Never public; reveal only via accepted connection requests. |
| | preferred_contact_method | enum | | | `in_platform_request` (default), `email`, `phone`, `linkedin`. |
| Community | community_affiliation_status | enum | R | SC | `self_declared_consented`, `verified`, `pending`, `unknown`, `not_disclosed`, `not_applicable` (samples). Never inferred from name, photo, family, employer or location. |
| | community_affiliation_source | text | | SC | How the affiliation was recorded, e.g. `registration_form_v1 self-declaration`, or the community organisation that confirmed it. |
| | community_organization, community_role, community_city | text | | SC | Shown publicly only when `community_participation_opt_in = true`. |
| | community_participation_opt_in, community_mentorship_opt_in, community_networking_opt_in | bool | | | Separate opt-ins. |
| Professional | current_job_title … languages_spoken | text/num | | PII | Self-reported; `years_of_experience` ≤ `total_career_experience`. `seniority_level`: `student`, `entry_level`, `mid_level`, `senior`, `lead`, `executive`, `founder`. |
| Education | highest_qualification … research_interests | text/int | | PII | `highest_qualification`: `secondary`, `diploma`, `bachelors`, `masters`, `doctorate`, `professional_qualification`. |
| Mentorship | mentorship_available … mentoring_currency | bool/text/num | | | `mentoring_fee_type`: `free`, `paid`, `sliding_scale`; fee numeric + ISO currency when paid. `job_referral_support` must stay `false` unless a written `referral_policy` exists – guidance is never a promise of employment or referral. |
| Location | country, state, city, locality | text | | PII | City/locality only – **never a home address**. |
| | work_location_type | enum | | | `onsite`, `hybrid`, `remote`. |
| | available_time_zone | text | | | IANA zone (e.g. `Asia/Kolkata`). |
| | availability_status | enum | | | `available`, `limited`, `not_available`. |
| Jobs | hiring_status | enum | | | `hiring_verified` (requires `job_application_url` to a live official posting checked on a recorded date), `not_hiring`, `unknown`. |
| | hiring_for_roles … industry_trends_or_advice | text/url | | | Only verified current openings. `referral_policy`: `not_offered`, `case_by_case`, `formal_company_programme`. |
| Platform | connection_request_enabled, messaging_enabled | bool | | | |
| | profile_visibility | enum | R | | `public`, `community_members_only`, `verified_members_only`, `private`, `test_environment_only` (samples). |
| | profile_consent_status | enum | R | | `granted`, `pending`, `withdrawn`, `not_applicable` (samples). |
| | consent_date | date | | | Required when consent is `granted`. |
| | identity_verification_status | enum | R | | `pending`, `verified`, `unverified`, `rejected`. |
| | professional_verification_method | text | | | e.g. `work_email_otp`, `video_call`, `employer_letter`, `community_reference`, `none`. |
| | verification_date, last_profile_updated_date | date | | | |
| | data_source | text | R | | `registration_form_v1`, `community_bulk_submission`, `synthetic_generator_v1`. |
| | source_url | url | | | Public source the professional pointed to, if any. |
| | record_created_date, record_updated_date | date | R | | |
| | additional_notes | text | | | Internal only. |

### 4.2 Sample data rules

- 300 synthetic profiles: 30 professional categories × 10, spanning entry-level to executive, founders, educators, recruiters, tradespeople and freelancers.
- Every sample has `profile_type=sample`, `profile_status=sample_only`, `profile_visibility=test_environment_only`, `community_affiliation_status=not_applicable`, `identity_verification_status=unverified`, `connection_request_enabled=false`, `messaging_enabled=false`, a `[SAMPLE]` headline, a fictional employer `Fictional … (sample)` and the note `SYNTHETIC TEST RECORD`.
- No email, phone, LinkedIn, photo or website is filled for samples (validated). Cities are real places so location filters can be tested; nothing else refers to real people or organisations.
- Load samples **only** into development/staging databases, or into a separate `professionals_sample` table. The `chk_sample_hidden` constraint and the `professionals_public_directory` view keep them out of public results even if loaded by mistake.

## 5. Verification

### 5.1 Courses

| `verification_status` | Meaning | Count |
|---|---|---|
| `verified` | Record built from the provider's official catalogue/API **and** its `course_url` returned HTTP 200 on `last_verified_date` (Coursera redirects followed; 404 control URLs confirmed each host returns 404 for missing pages) | 8,872 |
| `source_listed` | Built from the official catalogue but the individual URL was not link-checked (1,014 SWAYAM runs; a 75-URL sample from the same host all returned 200) | 1,014 |
| `unverified` | Link check could not complete (network error) | 1 |
| `broken_link` | URL returned 4xx/5xx – these 23 rows were removed and listed in `excluded_broken_links.csv` | 0 |

A URL is never marked verified because it matches a pattern. Fees, durations, ratings and instructors come only from the provider sources listed in §9.

### 5.2 Professionals – three independent checks

1. **Identity** (`identity_verification_status`, `professional_verification_method`, `verification_date`): the person is who they say they are – e.g. video call with a community coordinator, or OTP to a work email.
2. **Professional credentials**: job title/employer/qualifications checked against a document, work email domain or a public professional page the person controls. Record the method in `professional_verification_method`; leave unverified claims as self-reported in the bio.
3. **Community affiliation**: recorded **only** from the person's own explicit declaration on the consent form (`self_declared_consented`) or confirmation by a named community organisation with the person's permission (`verified`). Otherwise `unknown`, `pending` or `not_disclosed`.

A profile reaches `profile_status=active` only when identity is `verified` and consent is `granted`.

## 6. Why the production career file is empty

No real professionals have registered or consented yet, and the brief forbids scraping profiles, inferring religious identity, or fabricating real people. The production file is therefore delivered with headers only and must be populated through an opt-in registration form. Recommended intake:

1. Registration form collecting the fields in §4.1, with separate tick-boxes for: (a) publishing the profile, (b) displaying community affiliation, (c) mentorship listing, (d) sharing contact details with accepted connections.
2. Store the consent text version, timestamp (`consent_date`) and IP/session reference in a separate `consent_log` table.
3. Verification call or work-email OTP → set identity status and date.
4. Admin review → `profile_status=active`.

## 7. Consent – recording and revocation

- **Record**: `profile_consent_status=granted` + `consent_date`; keep the signed form version in `consent_log`. Community affiliation needs its own explicit opt-in (special-category data under India's DPDP Act 2023 and GDPR Art. 9 for EU/UK residents).
- **Partial withdrawal** (e.g. stop showing affiliation): clear the community fields, set the matching opt-in to `false`, update `record_updated_date`.
- **Full withdrawal**: set `profile_consent_status=withdrawn`, `profile_status=withdrawn`, `profile_visibility=private` immediately (removes the profile from `professionals_public_directory`), then delete or anonymise personal fields within the retention period set by the community's privacy policy (suggested ≤ 30 days). Keep only `professional_id`, dates and the withdrawal event in `consent_log`.
- Re-confirm consent annually; set `pending` and hide the profile if not re-confirmed.

## 8. Updating the datasets

- **Courses**: re-run the exports (Coursera `api.coursera.org/api/courses.v1`, Microsoft `learn.microsoft.com/api/catalog`, NPTEL `nptel.ac.in/courses/__data.json`, SWAYAM explorer GraphQL, freeCodeCamp curriculum on GitHub), then `python3 scripts/build_courses.py && python3 scripts/validate.py`. IDs are deterministic, so upserts on `course_id` update existing rows. Suggested cadence: monthly for SWAYAM (runs change each semester), quarterly for others. Re-link-check before each release and drop or flag 404s.
- **Retired content**: Microsoft certifications whose catalogue summary says “retired” are excluded (64 removed); repeat this check each refresh.
- **Professionals**: changes only through the profile owner or an admin acting on their written request; every change updates `record_updated_date` and `last_profile_updated_date`.

## 9. Import

### PostgreSQL (tested on PostgreSQL 16 – all files load with constraints enabled)

```bash
psql -d nextstep -f schema.sql
psql -d nextstep -c "\copy courses from 'course_platform_database.csv' csv header"
psql -d nextstep -c "\copy course_source_map from 'course_source_map.csv' csv header"
psql -d nextstep -c "\copy professionals from 'career_guidance_database.csv' csv header"
# development / staging only:
psql -d nextstep_dev -c "\copy professionals from 'career_guidance_sample_database.csv' csv header"
```

Empty fields load as `NULL`. Upserts: load into a staging table, then `INSERT … ON CONFLICT (course_id) DO UPDATE`.

### MongoDB

```bash
mongoimport --db nextstep --collection courses --type csv --headerline --ignoreBlanks --file course_platform_database.csv
```
Convert `true`/`false` strings and `"; "` lists in a post-import script (or use `--columnsHaveTypes` with a typed header).

### Node / Prisma / Sequelize

Parse with `csv-parse` (`{columns: true, skip_empty_lines: true}`), map `''` → `null`, `'true'/'false'` → boolean, split list fields on `"; "`, and `createMany` in batches of 500. Public pages must query `professionals_public_directory` (or an equivalent ORM scope filtering `profile_type='real' AND profile_status='active' AND profile_consent_status='granted' AND identity_verification_status='verified'`).

## 10. Sources and known limitations

| Source | Records | Notes |
|---|---|---|
| Coursera public catalog API + instructors/partners APIs | 4,150 | Stratified sample of the 24,705-course catalogue (≈13% per subdomain, min 60; English/Arabic/Hindi/Urdu preferred); 23 courses with 404 pages removed |
| Microsoft Learn Catalog API | 1,054 | 821 learning paths, 108 courses, 88 current certifications, 37 Applied Skills credentials |
| NPTEL course catalogue | 3,484 | Every course page confirmed via its outline endpoint; 1,031 enriched with the current SWAYAM-NPTEL run |
| SWAYAM course explorer | 1,107 | Current runs from AICTE, CEC, IGNOU, IIMB, INI, NCERT, NIOS, NITTTR, UGC and unmatched NPTEL runs; repeated runs collapsed |
| freeCodeCamp curriculum (GitHub) | 92 | Superblocks whose page returned 200 |

Limitations:
- **Not covered**: edX, FutureLearn, Udemy, Kaggle Learn, AWS Skill Builder, Cisco NetAcad, IBM SkillsBuild, Trailhead, HubSpot, Google Skills, Simplilearn, Infosys Springboard, Alison and professional bodies (PMI, CompTIA, ISC2…). Their catalogues were not reachable from the build environment or permission requests for them went unanswered. They are the priority for the next release.
- **Thin domains**: government/competitive-exam preparation (16), freelancing (5), vocational trades (28) and HR (42) – the sources used publish few such courses.
- **Coursera pricing, levels, ratings and skills** were not verified per course and are left empty/`unknown`.
- **Fees** for exams/certificates vary by country and run and are never recorded as numbers in this release.
- **Domain labels** are rule-based NextStep classifications.
- **NPTEL** keeps separate course IDs for some re-recorded or web/video versions of the same title (65 groups); they are kept as distinct records because they are distinct resources.
- **Career guidance**: zero verified professionals – production rollout depends on the opt-in registration flow in §6.
