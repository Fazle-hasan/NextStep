#!/usr/bin/env python3
"""Automated validation for the NextStep course and career-guidance CSVs. Writes out/validation_report.md and out/validation_results.json."""
import csv, json, re, os, sys, collections
from datetime import date
sys.path.insert(0, os.path.dirname(__file__))
import importlib.util

OUT = os.path.expanduser('~/work/out')

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    src = open(path).read()
    # only pull constant definitions (avoid re-running builds)
    ns = {}
    exec(compile(src.split('# ---------------------------------------------------------------- duration parsing')[0], path, 'exec'), ns) if 'courses' in name else None
    return ns

course_ns = load_module('courses', os.path.join(os.path.dirname(__file__), 'build_courses.py'))
COURSE_COLUMNS = course_ns['COLUMNS']
DOMAINS = set(course_ns['DOMAINS'])
career_src = open(os.path.join(os.path.dirname(__file__), 'build_career.py')).read()
cns = {}
exec(career_src.split('# category key')[0], cns)
CAREER_COLUMNS = cns['COLUMNS']

VOCAB = {
    'pricing_type': {'free', 'paid', 'freemium', 'free_audit', 'subscription', 'financial_aid_available', 'unknown'},
    'verification_status': {'verified', 'source_listed', 'unverified', 'broken_link'},
    'learning_mode': {'online_self_paced', 'online_cohort', 'instructor_led', 'hybrid', 'in_person', ''},
    'difficulty_level': {'beginner', 'intermediate', 'advanced', 'mixed', ''},
    'duration_unit': {'minutes', 'hours', 'days', 'weeks', 'months', ''},
    'provider_type': {'mooc_platform', 'technology_company', 'university', 'university_consortium', 'government_body', 'nonprofit', 'professional_body', 'training_company'},
    'enrollment_status': {'open', 'closed', 'upcoming', 'archived', ''},
    'certificate_type': {'certificate_of_completion', 'professional_certification', 'skills_credential', 'academic_credit', 'none', ''},
    'examination_type': {'final_exam', 'certification_exam', 'lab_based_assessment', 'quizzes_only', ''},
    'examination_mode': {'online_proctored', 'in_person_proctored', 'online_unproctored', 'online_or_test_centre', ''},
    'course_format': {'video_lectures', 'web_text_modules', 'interactive_modules', 'interactive_coding', 'guided_project', 'hands_on_lab', 'mixed', ''},
    'portfolio_value': {'high', 'medium', 'low', ''},
    'rating_source': {'microsoft_learn', 'coursera', ''},
    'data_source': {'coursera_catalog_api', 'microsoft_learn_catalog_api', 'nptel_course_catalog', 'swayam_course_explorer', 'freecodecamp_github_curriculum'},
}
BOOL_COURSE = ['course_materials_available', 'self_paced', 'free_certificate_available', 'financial_aid_available', 'scholarship_available',
               'certificate_available', 'examination_available', 'final_project_required', 'proctored_exam']
NUM_COURSE = ['course_duration', 'estimated_study_hours', 'course_fee', 'certificate_fee', 'examination_duration_minutes', 'passing_percentage',
              'number_of_assessments', 'continuing_education_credits', 'course_rating', 'rating_count']
DATE_COURSE = ['course_start_date', 'course_end_date', 'last_verified_date', 'record_created_date', 'record_updated_date']
URL_COURSE = ['syllabus_or_curriculum_url', 'course_url', 'enrollment_url', 'financial_aid_url', 'scholarship_url', 'exam_registration_url', 'official_source_url']
REQ_COURSE = ['course_id', 'course_name', 'course_slug', 'domain', 'provider_name', 'provider_type', 'course_url', 'pricing_type',
              'official_source_url', 'verification_status', 'data_source', 'record_created_date', 'record_updated_date']
PLACEHOLDERS = {'n/a', 'na', 'nil', '-', 'none available', 'not available', 'null', 'tbd', 'unknown?'}
URL_RX = re.compile(r'^https://[A-Za-z0-9.-]+\.[A-Za-z]{2,}(/[^\s]*)?$')
DATE_RX = re.compile(r'^\d{4}-\d{2}-\d{2}$')

def is_date(s):
    if not DATE_RX.match(s):
        return False
    try:
        date.fromisoformat(s); return True
    except ValueError:
        return False

def is_num(s):
    try:
        float(s); return True
    except ValueError:
        return False

def read(path):
    with open(path, encoding='utf-8', newline='') as fh:
        rdr = csv.reader(fh)
        header = next(rdr)
        rows = [r for r in rdr]
    return header, rows

res = {}
issues = collections.defaultdict(list)

# ================================================================ courses
h, raw = read(f'{OUT}/course_platform_database.csv')
res['course_header_matches_schema'] = h == COURSE_COLUMNS
res['course_header_missing'] = [c for c in COURSE_COLUMNS if c not in h]
res['course_header_extra'] = [c for c in h if c not in COURSE_COLUMNS]
bad_width = [i for i, r in enumerate(raw, 2) if len(r) != len(h)]
rows = [dict(zip(h, r)) for r in raw]
res['course_rows'] = len(rows)
res['course_rows_wrong_width'] = len(bad_width)

def dupcount(vals):
    c = collections.Counter(vals)
    return sum(v - 1 for v in c.values() if v > 1)
res['course_duplicate_ids'] = dupcount(r['course_id'] for r in rows)
res['course_duplicate_canonical_urls'] = dupcount(r['course_url'].rstrip('/').lower() for r in rows)
res['course_duplicate_slugs'] = dupcount(r['course_slug'] for r in rows)
res['course_duplicate_name_provider_instructor'] = dupcount((r['course_name'].lower(), r['provider_name'], r['instructor_name'].lower()) for r in rows)

for i, r in enumerate(rows, 2):
    rid = r['course_id']
    for c in REQ_COURSE:
        if not r[c]:
            issues['course_missing_required'].append(f'{rid}:{c}')
    for c, vocab in VOCAB.items():
        if c in r and r[c] not in vocab:
            issues['course_invalid_vocab'].append(f'{rid}:{c}={r[c]}')
    if r['domain'] not in DOMAINS:
        issues['course_invalid_domain'].append(f"{rid}:{r['domain']}")
    for c in BOOL_COURSE:
        if r[c] not in ('true', 'false', ''):
            issues['course_invalid_boolean'].append(f'{rid}:{c}={r[c]}')
    for c in NUM_COURSE:
        if r[c] and not is_num(r[c]):
            issues['course_invalid_numeric'].append(f'{rid}:{c}={r[c]}')
    for c in DATE_COURSE:
        if r[c] and not is_date(r[c]):
            issues['course_invalid_date'].append(f'{rid}:{c}={r[c]}')
    for c in URL_COURSE:
        if r[c] and not URL_RX.match(r[c]):
            issues['course_malformed_url'].append(f'{rid}:{c}={r[c]}')
    for c, v in r.items():
        if v.strip().lower() in PLACEHOLDERS:
            issues['course_placeholder_value'].append(f'{rid}:{c}={v}')
        if '\n' in v or '\r' in v:
            issues['course_embedded_newline'].append(f'{rid}:{c}')
        if v != v.strip():
            issues['course_untrimmed_whitespace'].append(f'{rid}:{c}')
    # contradictions
    if r['pricing_type'] == 'free' and r['course_fee'] and float(r['course_fee']) > 0:
        issues['course_contradiction'].append(f'{rid}: free but course_fee>0')
    for fee in ('course_fee', 'certificate_fee'):
        if r[fee] and float(r[fee]) > 0 and not r['currency']:
            issues['course_contradiction'].append(f'{rid}: {fee}>0 without currency')
    if r['certificate_available'] == 'false' and r['certificate_type'] not in ('', 'none'):
        issues['course_contradiction'].append(f'{rid}: certificate_type without certificate')
    if r['certificate_available'] != 'true' and (r['certificate_fee'] or r['free_certificate_available'] == 'true'):
        issues['course_contradiction'].append(f'{rid}: certificate fields without certificate_available=true')
    if r['free_certificate_available'] == 'true' and r['certificate_fee'] and float(r['certificate_fee']) > 0:
        issues['course_contradiction'].append(f'{rid}: free certificate with fee')
    if r['examination_available'] != 'true' and (r['exam_registration_url'] or r['proctored_exam'] == 'true' or r['examination_type']):
        issues['course_contradiction'].append(f'{rid}: exam fields without examination_available=true')
    if r['course_start_date'] and r['course_end_date'] and r['course_end_date'] < r['course_start_date']:
        issues['course_contradiction'].append(f'{rid}: end before start')
    if r['verification_status'] == 'verified' and not r['last_verified_date']:
        issues['course_contradiction'].append(f'{rid}: verified without last_verified_date')
    if (r['course_rating'] or r['rating_count']) and not r['rating_source']:
        issues['course_contradiction'].append(f'{rid}: rating without source')
    if r['course_rating'] and not (0 <= float(r['course_rating']) <= 5):
        issues['course_contradiction'].append(f'{rid}: rating outside 0-5')
    if r['duration_unit'] and not r['course_duration'] or r['course_duration'] and not r['duration_unit']:
        issues['course_contradiction'].append(f'{rid}: duration/unit mismatch')
    if r['certificate_type'] == 'professional_certification' and r['domain'] != 'professional_certifications':
        issues['course_contradiction'].append(f'{rid}: professional certification outside certification domain')

res['course_missing_value_pct'] = {c: round(100 * sum(1 for r in rows if not r[c]) / len(rows), 1) for c in COURSE_COLUMNS}
res['course_by_verification_status'] = dict(collections.Counter(r['verification_status'] for r in rows))
res['course_by_provider'] = dict(collections.Counter(r['provider_name'] for r in rows))
res['course_by_domain'] = dict(collections.Counter(r['domain'] for r in rows).most_common())
res['course_by_pricing_type'] = dict(collections.Counter(r['pricing_type'] for r in rows))
res['course_by_certificate_type'] = dict(collections.Counter(r['certificate_type'] or '(blank)' for r in rows))
res['course_by_language'] = dict(collections.Counter(r['course_language'] or '(blank)' for r in rows).most_common(12))

# link check summary from source map
_, mraw = read(f'{OUT}/course_source_map.csv')
mh = ['course_id', 'data_source', 'provider_course_id', 'canonical_url', 'offering_partner', 'source_category', 'raw_duration_text', 'link_check_status', 'link_check_date', 'notes']
maps = [dict(zip(mh, r)) for r in mraw]
lc = collections.defaultdict(collections.Counter)
for m in maps:
    lc[m['data_source']][m['link_check_status']] += 1
res['url_link_check_by_source'] = {k: dict(v) for k, v in lc.items()}
ids = {r['course_id'] for r in rows}
res['source_map_orphans'] = sum(1 for m in maps if m['course_id'] not in ids)
res['source_map_missing'] = len(ids - {m['course_id'] for m in maps})

# ================================================================ career guidance
CAREER_VOCAB = {
    'profile_type': {'real', 'sample'},
    'profile_status': {'active', 'inactive', 'pending_review', 'suspended', 'withdrawn', 'sample_only'},
    'community_affiliation_status': {'self_declared_consented', 'verified', 'pending', 'unknown', 'not_disclosed', 'not_applicable'},
    'profile_consent_status': {'granted', 'pending', 'withdrawn', 'not_applicable'},
    'identity_verification_status': {'pending', 'verified', 'unverified', 'rejected'},
    'profile_visibility': {'public', 'community_members_only', 'verified_members_only', 'private', 'test_environment_only'},
    'seniority_level': {'student', 'entry_level', 'mid_level', 'senior', 'lead', 'executive', 'founder', ''},
    'mentoring_fee_type': {'free', 'paid', 'sliding_scale', ''},
    'hiring_status': {'hiring_verified', 'not_hiring', 'unknown', ''},
    'preferred_contact_method': {'in_platform_request', 'email', 'phone', 'linkedin', ''},
}
CAREER_BOOL = [c for c in CAREER_COLUMNS if c.endswith('_opt_in') or c.endswith('_available') or c in (
    'connection_request_enabled', 'messaging_enabled', 'career_transition_support', 'entrepreneurship_guidance', 'higher_education_guidance',
    'scholarship_guidance', 'internship_guidance', 'job_referral_support', 'volunteer_availability', 'internship_opportunities', 'entry_level_opportunities')]
CAREER_DATES = ['consent_date', 'verification_date', 'last_profile_updated_date', 'record_created_date', 'record_updated_date', 'available_from_date']
CAREER_NUM = ['years_of_experience', 'total_career_experience', 'graduation_year', 'mentorship_capacity', 'mentoring_fee_amount']
PERSONAL_CONTACT = ['professional_email', 'professional_phone', 'linkedin_url', 'public_profile_url', 'personal_website', 'portfolio_url', 'profile_photo_url']

for fname, expect in (('career_guidance_database.csv', 'production'), ('career_guidance_sample_database.csv', 'sample')):
    ch, craw = read(f'{OUT}/{fname}')
    key = expect
    res[f'career_{key}_header_matches_schema'] = ch == CAREER_COLUMNS
    res[f'career_{key}_rows'] = len(craw)
    res[f'career_{key}_rows_wrong_width'] = sum(1 for r in craw if len(r) != len(ch))
    cr = [dict(zip(ch, r)) for r in craw]
    res[f'career_{key}_duplicate_ids'] = dupcount(r['professional_id'] for r in cr)
    for r in cr:
        pid = r['professional_id']
        for c, vocab in CAREER_VOCAB.items():
            if r[c] not in vocab:
                issues[f'career_{key}_invalid_vocab'].append(f'{pid}:{c}={r[c]}')
        for c in CAREER_BOOL:
            if r[c] not in ('true', 'false', ''):
                issues[f'career_{key}_invalid_boolean'].append(f'{pid}:{c}={r[c]}')
        for c in CAREER_DATES:
            if r[c] and not is_date(r[c]):
                issues[f'career_{key}_invalid_date'].append(f'{pid}:{c}')
        for c in CAREER_NUM:
            if r[c] and not is_num(r[c]):
                issues[f'career_{key}_invalid_numeric'].append(f'{pid}:{c}')
        if r['years_of_experience'] and r['total_career_experience'] and float(r['years_of_experience']) > float(r['total_career_experience']):
            issues[f'career_{key}_contradiction'].append(f'{pid}: years_of_experience > total_career_experience')
        if r['mentorship_available'] == 'false' and r['mentorship_capacity'] not in ('', '0'):
            issues[f'career_{key}_contradiction'].append(f'{pid}: capacity without mentorship')
        if r['job_referral_support'] == 'true' and r['referral_policy'] in ('', 'not_offered'):
            issues[f'career_{key}_contradiction'].append(f'{pid}: referral support without referral policy')
        if r['hiring_status'] == 'hiring_verified' and not r['job_application_url']:
            issues[f'career_{key}_contradiction'].append(f'{pid}: hiring_verified without job_application_url')
        if expect == 'production':
            if r['profile_type'] != 'real' or r['profile_status'] == 'sample_only':
                issues['career_production_contains_sample'].append(pid)
            if r['profile_consent_status'] != 'granted' or not r['consent_date']:
                issues['career_production_missing_consent'].append(pid)
            if r['community_affiliation_status'] in ('verified', 'self_declared_consented') and not r['community_affiliation_source']:
                issues['career_production_affiliation_without_source'].append(pid)
            if r['identity_verification_status'] == 'verified' and (not r['verification_date'] or not r['professional_verification_method']):
                issues['career_production_unsupported_verification'].append(pid)
            if r['profile_visibility'] == 'public' and r['identity_verification_status'] != 'verified':
                issues['career_production_public_unverified'].append(pid)
        else:
            if r['profile_type'] != 'sample' or r['profile_status'] != 'sample_only':
                issues['career_sample_misclassified_as_real'].append(pid)
            if r['profile_visibility'] != 'test_environment_only':
                issues['career_sample_visible_publicly'].append(pid)
            if r['community_affiliation_status'] != 'not_applicable':
                issues['career_sample_has_affiliation_claim'].append(pid)
            if r['identity_verification_status'] == 'verified':
                issues['career_sample_marked_verified'].append(pid)
            if any(r[c] for c in PERSONAL_CONTACT):
                issues['career_sample_has_contact_details'].append(pid)
            if 'sample' not in r['full_name'].lower():
                issues['career_sample_name_not_marked'].append(pid)
    if cr:
        res[f'career_{key}_missing_value_pct'] = {c: round(100 * sum(1 for r in cr if not r[c]) / len(cr), 1) for c in CAREER_COLUMNS}

res['issue_counts'] = {k: len(v) for k, v in issues.items()}
res['issue_examples'] = {k: v[:5] for k, v in issues.items()}
json.dump(res, open(f'{OUT}/validation_results.json', 'w'), indent=1)
print(json.dumps({k: v for k, v in res.items() if 'missing_value_pct' not in k}, indent=1)[:6000])
