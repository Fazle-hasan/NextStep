#!/usr/bin/env python3
"""Build career guidance files.

career_guidance_database.csv          production file – ONLY real, consented, verified profiles (none collected yet -> header only)
career_guidance_sample_database.csv   clearly-labelled synthetic test records (profile_type=sample, profile_status=sample_only)
"""
import csv, os, random

OUT = os.path.expanduser('~/work/out')
TODAY = '2026-10-03'

COLUMNS = """professional_id profile_type profile_status full_name preferred_name professional_headline professional_bio profile_photo_url public_profile_url linkedin_url portfolio_url personal_website professional_email professional_phone preferred_contact_method
community_affiliation_status community_affiliation_source community_organization community_role community_city community_participation_opt_in community_mentorship_opt_in community_networking_opt_in
current_job_title current_company industry functional_domain specialization seniority_level years_of_experience total_career_experience employment_type employment_status previous_companies previous_job_titles professional_achievements notable_projects professional_certifications technical_skills soft_skills tools_and_technologies languages_spoken
highest_qualification field_of_study institution_name graduation_year additional_qualifications relevant_training research_interests
mentorship_available mentorship_domains mentorship_topics target_mentee_groups mentorship_format mentorship_location mentorship_languages mentorship_capacity preferred_mentorship_frequency mentorship_duration career_guidance_available resume_review_available mock_interview_available interview_preparation_available portfolio_review_available career_transition_support entrepreneurship_guidance higher_education_guidance scholarship_guidance internship_guidance job_referral_support professional_networking_available volunteer_availability mentoring_fee_type mentoring_fee_amount mentoring_currency
country state city locality work_location_type remote_guidance_available in_person_guidance_available available_time_zone preferred_days preferred_time_slots availability_status available_from_date
hiring_status hiring_for_roles hiring_departments internship_opportunities entry_level_opportunities referral_policy job_application_url company_careers_url skills_required_for_roles industry_trends_or_advice
preferred_connection_purpose connection_request_enabled messaging_enabled profile_visibility profile_consent_status consent_date identity_verification_status professional_verification_method verification_date last_profile_updated_date data_source source_url record_created_date record_updated_date additional_notes""".split()

# category key, industry, functional_domain, titles by seniority, specialisations, technical skills, tools, certs (generic names only), field of study
CATS = [
 ('software_engineering', 'Information Technology', 'software_engineering', ['Software Engineer', 'Senior Software Engineer', 'Engineering Manager'], ['Backend systems', 'Frontend engineering', 'Mobile apps'], 'Java; Python; System design; REST APIs', 'Git; Docker; VS Code', 'Computer Science'),
 ('data_analytics_bi', 'Information Technology', 'data_analytics', ['Data Analyst', 'Senior Data Analyst', 'Analytics Manager'], ['BI reporting', 'Product analytics', 'Marketing analytics'], 'SQL; Statistics; Data visualisation', 'Power BI; Excel; Tableau', 'Statistics'),
 ('data_science_ai', 'Information Technology', 'data_science_ai', ['Data Scientist', 'Senior ML Engineer', 'Head of AI'], ['NLP', 'Computer vision', 'Forecasting'], 'Python; Machine learning; Deep learning', 'PyTorch; scikit-learn; Jupyter', 'Computer Science'),
 ('cloud_devops', 'Information Technology', 'cloud_devops', ['Cloud Engineer', 'Senior DevOps Engineer', 'Platform Engineering Lead'], ['Kubernetes platforms', 'CI/CD', 'Cloud cost optimisation'], 'Linux; Networking; Infrastructure as code', 'Terraform; Kubernetes; GitHub Actions', 'Information Technology'),
 ('cybersecurity', 'Information Technology', 'cybersecurity', ['Security Analyst', 'Senior Security Engineer', 'Security Manager'], ['SOC operations', 'Application security', 'Governance and risk'], 'Threat detection; Incident response; Risk assessment', 'SIEM tools; Burp Suite; Wireshark', 'Information Security'),
 ('it_support_networking', 'Information Technology', 'it_support_networking', ['IT Support Specialist', 'Network Engineer', 'IT Infrastructure Manager'], ['Enterprise networking', 'End-user support', 'Systems administration'], 'Routing and switching; Windows administration; Troubleshooting', 'Ticketing systems; Active Directory', 'Electronics and Communication'),
 ('product_management', 'Information Technology', 'product_management', ['Associate Product Manager', 'Product Manager', 'Director of Product'], ['B2B SaaS', 'Consumer apps', 'Platform products'], 'Product discovery; Roadmapping; Metrics', 'Jira; Figma; Amplitude', 'Business Administration'),
 ('business_analysis', 'Consulting', 'business_analysis', ['Business Analyst', 'Senior Business Analyst', 'Lead Business Analyst'], ['Process improvement', 'Requirements engineering', 'ERP implementations'], 'Requirements gathering; Process mapping; SQL', 'Visio; Jira; Excel', 'Business Administration'),
 ('project_management', 'Construction', 'project_management', ['Project Coordinator', 'Project Manager', 'Programme Director'], ['Agile delivery', 'Infrastructure projects', 'PMO setup'], 'Planning; Risk management; Stakeholder management', 'MS Project; Jira; Smartsheet', 'Engineering'),
 ('finance_accounting', 'Financial Services', 'finance_accounting', ['Accountant', 'Senior Financial Analyst', 'Finance Controller'], ['Financial reporting', 'Taxation', 'FP&A'], 'Accounting standards; Financial modelling; Taxation', 'Tally; SAP; Excel', 'Commerce'),
 ('banking_financial_services', 'Banking', 'banking', ['Relationship Officer', 'Credit Manager', 'Branch Head'], ['Retail banking', 'Credit appraisal', 'Islamic finance'], 'Credit analysis; KYC/AML; Financial products', 'Core banking systems; Excel', 'Finance'),
 ('human_resources', 'Human Resources', 'human_resources', ['HR Executive', 'HR Business Partner', 'Head of HR'], ['Talent acquisition', 'Learning and development', 'Compensation'], 'Recruitment; Employee relations; HR analytics', 'HRMS tools; LinkedIn Recruiter', 'Human Resource Management'),
 ('sales_business_development', 'Sales', 'sales_business_development', ['Sales Executive', 'Business Development Manager', 'Regional Sales Head'], ['B2B sales', 'Channel sales', 'Key accounts'], 'Prospecting; Negotiation; CRM management', 'Salesforce; HubSpot', 'Marketing'),
 ('marketing_communications', 'Marketing', 'marketing_communications', ['Marketing Executive', 'Digital Marketing Manager', 'Head of Marketing'], ['Performance marketing', 'Content marketing', 'Brand management'], 'SEO; Paid media; Content strategy', 'Google Analytics; Meta Ads Manager; Canva', 'Mass Communication'),
 ('entrepreneurship_startups', 'Startups', 'entrepreneurship', ['Founder', 'Co-founder and CEO', 'Serial Entrepreneur'], ['EdTech', 'Food and retail', 'Social enterprise'], 'Business planning; Fundraising; Go-to-market', 'Notion; Google Workspace', 'Business Administration'),
 ('core_engineering', 'Engineering', 'core_engineering', ['Site Engineer', 'Senior Design Engineer', 'Engineering Manager'], ['Structural design', 'Mechanical design', 'Electrical systems'], 'CAD; Design calculations; Quality control', 'AutoCAD; SolidWorks; ETABS', 'Civil Engineering'),
 ('architecture_design', 'Architecture', 'architecture_design', ['Junior Architect', 'Architect', 'Principal Architect'], ['Residential design', 'Urban design', 'Interior architecture'], 'Architectural design; Building codes; 3D visualisation', 'Revit; SketchUp; AutoCAD', 'Architecture'),
 ('healthcare_allied', 'Healthcare', 'healthcare', ['Staff Nurse', 'Physiotherapist', 'Hospital Administrator'], ['Clinical care', 'Rehabilitation', 'Hospital operations'], 'Patient care; Clinical documentation; Health administration', 'Hospital information systems', 'Nursing'),
 ('education_academia', 'Education', 'education', ['Teacher', 'Assistant Professor', 'School Principal'], ['STEM teaching', 'Curriculum design', 'Islamic studies education'], 'Lesson planning; Assessment design; Classroom management', 'Google Classroom; Moodle', 'Education'),
 ('research_development', 'Research', 'research_development', ['Research Associate', 'Scientist', 'R&D Lead'], ['Materials research', 'Biotech research', 'Social research'], 'Research design; Data analysis; Scientific writing', 'R; MATLAB; LaTeX', 'Life Sciences'),
 ('law_legal', 'Legal Services', 'law_legal', ['Associate Advocate', 'Senior Associate', 'Partner'], ['Corporate law', 'Litigation', 'Family law'], 'Legal research; Drafting; Advocacy', 'Legal research databases', 'Law'),
 ('government_public_admin', 'Government', 'public_administration', ['Section Officer', 'Deputy Director', 'Senior Civil Servant'], ['Public policy', 'Programme administration', 'Civil services preparation'], 'Policy analysis; Public finance; Administration', 'E-office systems', 'Public Administration'),
 ('media_creative', 'Media', 'media_creative', ['Content Writer', 'Video Producer', 'Creative Director'], ['Journalism', 'Video production', 'Graphic design'], 'Storytelling; Editing; Visual design', 'Adobe Premiere Pro; Photoshop', 'Journalism'),
 ('supply_chain_logistics', 'Logistics', 'supply_chain', ['Logistics Coordinator', 'Supply Chain Manager', 'Head of Operations'], ['Procurement', 'Warehousing', 'Distribution planning'], 'Inventory planning; Procurement; Vendor management', 'SAP MM; Excel', 'Supply Chain Management'),
 ('manufacturing_operations', 'Manufacturing', 'operations', ['Production Engineer', 'Plant Manager', 'VP Operations'], ['Lean manufacturing', 'Quality assurance', 'Plant operations'], 'Lean; Six Sigma; Production planning', 'ERP systems; Minitab', 'Mechanical Engineering'),
 ('consulting', 'Consulting', 'consulting', ['Analyst', 'Consultant', 'Engagement Manager'], ['Strategy consulting', 'Operations consulting', 'Technology consulting'], 'Problem structuring; Financial analysis; Presentations', 'Excel; PowerPoint', 'Management'),
 ('hospitality_tourism', 'Hospitality', 'hospitality_tourism', ['Front Office Executive', 'Hotel Operations Manager', 'General Manager'], ['Hotel operations', 'Travel and pilgrimage tourism', 'Food and beverage'], 'Guest relations; Operations; Revenue management', 'Property management systems', 'Hotel Management'),
 ('skilled_trades_vocational', 'Skilled Trades', 'skilled_trades', ['Electrician', 'HVAC Technician', 'Workshop Supervisor'], ['Electrical installation', 'Refrigeration and AC', 'Automotive repair'], 'Installation; Safety compliance; Troubleshooting', 'Hand and power tools; Multimeters', 'Vocational training'),
 ('freelancing_independent', 'Freelancing', 'freelancing', ['Freelance Designer', 'Independent Consultant', 'Freelance Developer'], ['Web design', 'Translation', 'Bookkeeping services'], 'Client management; Proposal writing; Pricing', 'Upwork; Fiverr; Notion', 'Design'),
 ('social_impact_community', 'Non-profit', 'social_impact', ['Programme Officer', 'Programme Manager', 'Executive Director'], ['Education access', 'Livelihoods', 'Community health'], 'Programme design; Monitoring and evaluation; Fundraising', 'Excel; KoboToolbox', 'Social Work'),
]

SENIORITY = [('entry_level', 1, 3), ('mid_level', 4, 9), ('senior', 10, 15), ('lead', 12, 20), ('executive', 18, 30)]
CITIES = [('India', 'Maharashtra', 'Mumbai'), ('India', 'Uttar Pradesh', 'Lucknow'), ('India', 'Telangana', 'Hyderabad'),
          ('India', 'Delhi', 'New Delhi'), ('India', 'Karnataka', 'Bengaluru'), ('India', 'Maharashtra', 'Pune'),
          ('India', 'West Bengal', 'Kolkata'), ('India', 'Tamil Nadu', 'Chennai'), ('India', 'Jammu and Kashmir', 'Srinagar'),
          ('India', 'Ladakh', 'Kargil'), ('India', 'Bihar', 'Patna'), ('India', 'Gujarat', 'Ahmedabad'),
          ('United Arab Emirates', 'Dubai', 'Dubai'), ('United Kingdom', 'England', 'London'), ('Canada', 'Ontario', 'Toronto')]
TZ = {'India': 'Asia/Kolkata', 'United Arab Emirates': 'Asia/Dubai', 'United Kingdom': 'Europe/London', 'Canada': 'America/Toronto'}
QUAL = {'entry_level': 'bachelors', 'mid_level': 'bachelors', 'senior': 'masters', 'lead': 'masters', 'executive': 'masters'}
SOFT = ['Communication', 'Mentoring', 'Problem solving', 'Teamwork', 'Leadership', 'Time management', 'Negotiation', 'Public speaking']
TOPICS = ['Career planning', 'Resume and LinkedIn profile', 'Interview preparation', 'Skill roadmap', 'Higher studies abroad', 'Switching careers',
          'First job search', 'Freelancing basics', 'Starting a business', 'Scholarship applications']
MENTEES = ['school_students', 'undergraduate_students', 'postgraduate_students', 'fresh_graduates', 'early_career_professionals', 'career_changers', 'women_returning_to_work']
DAYS = ['saturday', 'sunday', 'weekdays', 'friday']
SLOTS = ['morning', 'afternoon', 'evening']

def tf(x):
    return 'true' if x else 'false'

def build_samples(n_per_cat=10, seed=20261003):
    rnd = random.Random(seed)
    rows, k = [], 0
    for cat in CATS:
        key, industry, fdom, titles, specs, tech, tools, field = cat
        for j in range(n_per_cat):
            k += 1
            sen, lo, hi = SENIORITY[j % len(SENIORITY)]
            title = titles[0] if sen == 'entry_level' else (titles[1] if sen in ('mid_level', 'senior') else titles[2])
            yrs = rnd.randint(lo, hi)
            country, state, city = rnd.choice(CITIES)
            mentor = sen != 'entry_level' or rnd.random() < 0.4
            remote = rnd.random() < 0.85
            inperson = rnd.random() < 0.4
            topics = rnd.sample(TOPICS, 3)
            pid = f'PRO-SAMPLE-{k:04d}'
            r = {c: '' for c in COLUMNS}
            r.update({
                'professional_id': pid, 'profile_type': 'sample', 'profile_status': 'sample_only',
                'full_name': f'Sample Professional {k:04d}', 'preferred_name': f'Sample {k:04d}',
                'professional_headline': f'[SAMPLE] {title} – {specs[j % len(specs)]}',
                'professional_bio': f'Synthetic test profile for application development. Represents a {sen.replace("_", " ")} {title.lower()} in {industry.lower()}. Not a real person.',
                'preferred_contact_method': 'in_platform_request',
                'community_affiliation_status': 'not_applicable', 'community_affiliation_source': 'not_applicable',
                'community_organization': 'Sample Community Organisation (fictional)', 'community_role': rnd.choice(['volunteer_mentor', 'member', 'event_volunteer']),
                'community_city': city,
                'community_participation_opt_in': tf(rnd.random() < 0.7), 'community_mentorship_opt_in': tf(mentor), 'community_networking_opt_in': tf(rnd.random() < 0.8),
                'current_job_title': title, 'current_company': f'Fictional {industry} Company {chr(65 + j)} (sample)', 'industry': industry,
                'functional_domain': fdom, 'specialization': specs[j % len(specs)], 'seniority_level': sen,
                'years_of_experience': str(yrs), 'total_career_experience': str(yrs + (rnd.randint(0, 2) if sen != 'entry_level' else 0)),
                'employment_type': 'self_employed' if key in ('entrepreneurship_startups', 'freelancing_independent') else 'full_time',
                'employment_status': 'self_employed' if key in ('entrepreneurship_startups', 'freelancing_independent') else 'employed',
                'previous_companies': '' if sen == 'entry_level' else f'Fictional Previous Employer {chr(75 + j)} (sample)',
                'previous_job_titles': '' if sen == 'entry_level' else titles[0],
                'technical_skills': tech, 'soft_skills': '; '.join(rnd.sample(SOFT, 3)), 'tools_and_technologies': tools,
                'languages_spoken': '; '.join(['English', 'Urdu', 'Hindi'] if country == 'India' else ['English', 'Arabic'] if country == 'United Arab Emirates' else ['English']),
                'highest_qualification': QUAL[sen] if key not in ('skilled_trades_vocational',) else 'diploma',
                'field_of_study': field, 'institution_name': 'Sample University (fictional)',
                'graduation_year': str(2026 - yrs - rnd.randint(0, 1)),
                'mentorship_available': tf(mentor),
                'mentorship_domains': fdom if mentor else '', 'mentorship_topics': '; '.join(topics) if mentor else '',
                'target_mentee_groups': '; '.join(rnd.sample(MENTEES, 2)) if mentor else '',
                'mentorship_format': ('one_on_one; group' if rnd.random() < 0.5 else 'one_on_one') if mentor else '',
                'mentorship_location': ('online' if not inperson else 'online; in_person') if mentor else '',
                'mentorship_languages': 'English; Urdu' if country == 'India' else 'English',
                'mentorship_capacity': str(rnd.randint(1, 5)) if mentor else '0',
                'preferred_mentorship_frequency': rnd.choice(['weekly', 'fortnightly', 'monthly']) if mentor else '',
                'mentorship_duration': rnd.choice(['1_month', '3_months', '6_months', 'ongoing']) if mentor else '',
                'career_guidance_available': tf(mentor), 'resume_review_available': tf(mentor and rnd.random() < 0.7),
                'mock_interview_available': tf(mentor and rnd.random() < 0.5), 'interview_preparation_available': tf(mentor and rnd.random() < 0.6),
                'portfolio_review_available': tf(mentor and key in ('media_creative', 'architecture_design', 'freelancing_independent', 'software_engineering')),
                'career_transition_support': tf(mentor and rnd.random() < 0.4), 'entrepreneurship_guidance': tf(key == 'entrepreneurship_startups'),
                'higher_education_guidance': tf(mentor and rnd.random() < 0.4), 'scholarship_guidance': tf(mentor and rnd.random() < 0.3),
                'internship_guidance': tf(mentor and rnd.random() < 0.5), 'job_referral_support': 'false',
                'professional_networking_available': tf(rnd.random() < 0.8), 'volunteer_availability': tf(mentor),
                'mentoring_fee_type': 'free' if mentor else '', 'mentoring_fee_amount': '0' if mentor else '', 'mentoring_currency': '',
                'country': country, 'state': state, 'city': city,
                'work_location_type': rnd.choice(['onsite', 'hybrid', 'remote']),
                'remote_guidance_available': tf(mentor and remote), 'in_person_guidance_available': tf(mentor and inperson),
                'available_time_zone': TZ[country], 'preferred_days': '; '.join(rnd.sample(DAYS, 2)), 'preferred_time_slots': rnd.choice(SLOTS),
                'availability_status': ('available' if mentor else 'not_available'), 'available_from_date': TODAY,
                'hiring_status': 'unknown', 'referral_policy': 'not_offered',
                'skills_required_for_roles': '', 'industry_trends_or_advice': '',
                'preferred_connection_purpose': '; '.join(['mentorship', 'career_advice'] if mentor else ['networking']),
                'connection_request_enabled': 'false', 'messaging_enabled': 'false',
                'profile_visibility': 'test_environment_only', 'profile_consent_status': 'not_applicable', 'consent_date': '',
                'identity_verification_status': 'unverified', 'professional_verification_method': 'none', 'verification_date': '',
                'last_profile_updated_date': TODAY, 'data_source': 'synthetic_generator_v1', 'source_url': '',
                'record_created_date': TODAY, 'record_updated_date': TODAY,
                'additional_notes': 'SYNTHETIC TEST RECORD – not a real person; must never appear in public search results.',
            })
            rows.append(r)
    return rows

def write(path, rows):
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS, quoting=csv.QUOTE_MINIMAL, lineterminator='\n')
        w.writeheader()
        w.writerows(rows)

if __name__ == '__main__':
    write(f'{OUT}/career_guidance_database.csv', [])  # no real consented profiles have been collected yet
    s = build_samples()
    write(f'{OUT}/career_guidance_sample_database.csv', s)
    print('production rows 0; sample rows', len(s))
