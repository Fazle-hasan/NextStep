#!/usr/bin/env python3
"""Build course_platform_database.csv from official provider catalog exports.

Inputs (raw/):
  coursera.tsv          Coursera public catalog API (api.coursera.org/api/courses.v1) – stratified selection
  mslearn.json          Microsoft Learn Catalog API (learn.microsoft.com/api/catalog)
  nptel.tsv             NPTEL course catalog (nptel.ac.in/courses) + per-course outline check
  swayam.json           SWAYAM course explorer (swayam.gov.in/explorer, GraphQL courseList)
  ../src/fcc_*.json     freeCodeCamp curriculum metadata (github.com/freeCodeCamp/freeCodeCamp)
  *linkcheck*.json      link-check results gathered on 2026-10-03
Outputs (out/):
  course_platform_database.csv, course_source_map.csv
"""
import csv, json, re, hashlib, os, unicodedata, html
from datetime import datetime, timedelta, timezone

RAW = os.path.expanduser('~/work/raw')
SRC = os.path.expanduser('~/src')
OUT = os.path.expanduser('~/work/out')
os.makedirs(OUT, exist_ok=True)
TODAY = '2026-10-03'

COLUMNS = """course_id course_name course_slug course_description domain sub_domain subject skills_taught prerequisites target_audience
difficulty_level course_duration duration_unit estimated_study_hours learning_mode course_language course_format syllabus_or_curriculum_url learning_outcomes practical_projects course_materials_available
provider_name provider_type instructor_name course_url enrollment_url enrollment_status course_start_date course_end_date self_paced batch_availability
pricing_type course_fee currency free_certificate_available financial_aid_available financial_aid_url scholarship_available scholarship_url accessibility_features
certificate_available certificate_type certificate_issuing_organization certificate_fee examination_available examination_type examination_mode examination_duration_minutes passing_percentage number_of_assessments final_project_required proctored_exam exam_registration_url
relevant_job_roles career_relevance industry_recognition accreditation_details continuing_education_credits portfolio_value
course_rating rating_source rating_count official_source_url verification_status last_verified_date data_source record_created_date record_updated_date""".split()

MAP_COLUMNS = ['course_id', 'data_source', 'provider_course_id', 'canonical_url', 'offering_partner',
               'source_category', 'raw_duration_text', 'link_check_status', 'link_check_date', 'notes']

# ---------------------------------------------------------------- helpers
def clean(s):
    if s is None:
        return ''
    s = html.unescape(str(s))
    s = re.sub(r'<[^>]+>', ' ', s)
    s = s.replace(' ', ' ')
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def slugify(s):
    s = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode()
    s = re.sub(r'[^a-zA-Z0-9]+', '-', s.lower()).strip('-')
    return s[:80].strip('-') or 'course'

def cid(source, pid):
    return 'CRS-' + hashlib.sha1(f'{source}|{pid}'.encode()).hexdigest()[:12].upper()

def b(v):
    if v is None or v == '':
        return ''
    return 'true' if v else 'false'

def num(v):
    if v is None or v == '':
        return ''
    if isinstance(v, float):
        v = round(v, 1)
        return str(int(v)) if v == int(v) else str(v)
    return str(v)

def ist_date(iso):
    """SWAYAM timestamps are UTC midnight-IST (18:30Z); convert to the IST calendar date."""
    if not iso:
        return ''
    try:
        dt = datetime.fromisoformat(iso.replace('Z', '+00:00').replace('.000000', ''))
        return (dt.astimezone(timezone(timedelta(hours=5, minutes=30)))).date().isoformat()
    except Exception:
        return ''

# ---------------------------------------------------------------- domain classification
DOMAINS = [
    'computer_science_software_engineering', 'data_analytics_business_intelligence', 'artificial_intelligence_machine_learning',
    'generative_ai_data_science', 'cloud_computing_devops', 'cybersecurity_networking', 'web_mobile_development',
    'database_sql_data_engineering', 'ui_ux_product_management', 'business_analysis_project_management',
    'finance_accounting_banking', 'marketing_digital_marketing', 'human_resources_talent_acquisition',
    'communication_english_language', 'entrepreneurship_business_development', 'teaching_education_instructional_design',
    'government_competitive_exam_preparation', 'healthcare_administration_allied_health', 'vocational_technical_skills',
    'freelancing_remote_work', 'professional_certifications', 'personal_development_workplace_skills',
    # additional domains supported by the sourced catalogues
    'business_management_leadership', 'engineering_core', 'science_mathematics', 'humanities_social_sciences',
    'law_legal_studies', 'arts_design_media', 'agriculture_environment_sustainability', 'languages_other',
]

R = lambda p: re.compile(p, re.I)
RULES = [
    (R(r'freelanc|remote work|\bgig economy|upwork|fiverr'), 'freelancing_remote_work'),
    (R(r'\bupsc\b|\bssc\b|civil services|competitive exam|\bgate\b.*exam|\bneet\b|\bjee\b|\bgre\b|\bgmat\b|\bmcat\b|\bielts\b|\btoefl\b|test prep|exam prep|\btsi\b'), 'government_competitive_exam_preparation'),
    (R(r'generative ai|\bgen ?ai\b|\bllms?\b|large language|prompt(ing)? engineer|prompting|chatgpt|\bgpt\b|copilot|gemini|\brag\b|ai agents?|agentic|langchain|bedrock|diffusion model|multi-agent|vector (db|database)|foundation model'), 'generative_ai_data_science'),
    (R(r'data scien'), 'generative_ai_data_science'),
    (R(r'machine learning|deep learning|neural net|artificial intelligence|\bai\b|computer vision|natural language|\bnlp\b|reinforcement learning|tensorflow|pytorch|keras|scikit|predictive model'), 'artificial_intelligence_machine_learning'),
    (R(r'cyber|ethical hack|penetration test|forensic|cryptograph|firewall|threat|\bsoc\b|siem|malware|vulnerab|information security|network security|\bcissp|zero trust|identity and access|burp suite|(?<!food )(?<!social )security'), 'cybersecurity_networking'),
    (R(r'\bnetwork(ing|s)?\b(?! science)|cisco|ccna|wireshark|tcp/ip|routing|switching|\bvlan|\b5g\b|wireless'), 'cybersecurity_networking'),
    (R(r'cloud|\baws\b|amazon web|azure|google cloud|\bgcp\b|kubernetes|docker|devops|terraform|ansible|serverless|ci/cd|jenkins|site reliability|\bsre\b|microservice|\blinux\b|containers?\b|\beks\b|\bgke\b|lambda'), 'cloud_computing_devops'),
    (R(r'\bsql\b|database|data engineer|\betl\b|data warehous|apache spark|\bspark\b|hadoop|big data|postgres|mysql|mongodb|nosql|snowflake|databricks|data pipeline|kafka|data lake|data integration|talend|fabric'), 'database_sql_data_engineering'),
    (R(r'data analy|analytics|power bi|tableau|excel|spreadsheet|visuali[sz]|dashboard|business intelligence|statistic|looker|\bspss\b|\bstata\b|\bsas\b|regression|data-driven'), 'data_analytics_business_intelligence'),
    (R(r'web dev|\bhtml|\bcss\b|javascript|typescript|react|angular|vue\b|node\.?js|front[- ]end|back[- ]end|full[- ]stack|android|\bios\b|flutter|kotlin|swift|mobile app|django|flask|\bphp\b|wordpress|website|\bapi(s)?\b|tailwind|nestjs|next\.js|web app'), 'web_mobile_development'),
    (R(r'\bux\b|\bui\b|user experience|user interface|figma|product manag|product owner|product strategy|design thinking|roadmap'), 'ui_ux_product_management'),
    (R(r'project manag|\bpmp\b|agile|scrum|business analy|kanban|program management|six sigma|\blean\b|requirements|operations management|quality management|\btqm\b|supply chain|logistics|procurement|raci'), 'business_analysis_project_management'),
    (R(r'financ|accounting|\bbank|invest|\btax|audit|budget|fintech|insurance|wealth|trading|valuation|bookkeep|\bcfa\b|mortgage|portfolio|asset management|mergers|capital market|credit risk|actuar'), 'finance_accounting_banking'),
    (R(r'human resource|\bhr\b|recruit|talent|hiring|compensation|employee|workforce|people management|retention|payroll|labou?r law'), 'human_resources_talent_acquisition'),
    (R(r'marketing|\bseo\b|social media|advertis|brand|content strateg|e-?commerce|customer (experience|service|success)|copywrit|campaign|digital media'), 'marketing_digital_marketing'),
    (R(r'entrepreneur|startup|start-up|small business|venture|business model|\bsales\b|selling|negotiat|business development|innovation'), 'entrepreneurship_business_development'),
    (R(r'english|writing|communicat|speaking|presentation|grammar|public speak|storytelling|business english|phone'), 'communication_english_language'),
    (R(r'teach|instructional design|pedagog|learning design|e-?learning|classroom|curriculum|educator|\bschool\b|course design|education'), 'teaching_education_instructional_design'),
    (R(r'health|medical|clinic|patient|nurs|hospital|pharma|epidemiolog|anatomy|physiolog|nutrition|mental|psycholog|phlebotom|therapy|disease|medicine|dental|ehr\b|well-being|wellbeing'), 'healthcare_administration_allied_health'),
    (R(r'welding|plumb|electrician|carpentr|hvac|automotive|beauty|tailor|culinary|cooking|hospitality|tourism|retail|hotel|food (processing|safety)|fashion|textile'), 'vocational_technical_skills'),
    (R(r'agricultur|farming|dairy|livestock|crop|soil|forestr|agroforest|climate|sustainab|environment|energy|renewable|water resource'), 'agriculture_environment_sustainability'),
    (R(r'leadership|management|manager|strategy|strategic|governance|organi[sz]ational|consulting|team'), 'business_management_leadership'),
    (R(r'career|productivity|mindful|resilience|emotional intelligence|time management|critical thinking|problem solving|soft skill|interview|resume|personal development|happiness|well-being|charisma|habits?|decision'), 'personal_development_workplace_skills'),
    (R(r'programming|python|\bjava\b|c\+\+|\bc#|golang|\bgo\b|rust|software|algorithm|data structure|computer science|coding|\bgit\b|unit test|testing|operating system|compiler|\.net|object[- ]oriented|\boop\b|bash|command line|scripting|game develop|unity|unreal|godot|blockchain'), 'computer_science_software_engineering'),
    (R(r'\blaw\b|legal|constitution|contract|patent|trademark|rights|court|justice'), 'law_legal_studies'),
    (R(r'\bart\b|\barts\b|animation|\b3d (model|art|anim)|film|photograph|music|drawing|graphic design|\bcanva\b|adobe|premiere|after effects|blender|\bmaya\b|sketchup|video edit|videograph|illustrat|painting|interior design|fashion design|visual design|creative'), 'arts_design_media'),
]

COURSERA_FALLBACK = {
    'software-development': 'computer_science_software_engineering', 'algorithms': 'computer_science_software_engineering',
    'computer-security-and-networks': 'cybersecurity_networking', 'security': 'cybersecurity_networking', 'networking': 'cybersecurity_networking',
    'mobile-and-web-development': 'web_mobile_development', 'design-and-product': 'ui_ux_product_management',
    'cloud-computing': 'cloud_computing_devops', 'support-and-operations': 'cloud_computing_devops',
    'data-management': 'database_sql_data_engineering', 'data-analysis': 'data_analytics_business_intelligence',
    'probability-and-statistics': 'data_analytics_business_intelligence', 'machine-learning': 'artificial_intelligence_machine_learning',
    'leadership-and-management': 'business_management_leadership', 'business-strategy': 'business_management_leadership',
    'business-essentials': 'business_management_leadership', 'finance': 'finance_accounting_banking', 'marketing': 'marketing_digital_marketing',
    'entrepreneurship': 'entrepreneurship_business_development', 'personal-development': 'personal_development_workplace_skills',
    'education': 'teaching_education_instructional_design', 'learning-english': 'communication_english_language',
    'other-languages': 'languages_other', 'public-health': 'healthcare_administration_allied_health', 'patient-care': 'healthcare_administration_allied_health',
    'healthcare-management': 'healthcare_administration_allied_health', 'health-informatics': 'healthcare_administration_allied_health',
    'nutrition': 'healthcare_administration_allied_health', 'psychology': 'healthcare_administration_allied_health',
    'animal-health': 'agriculture_environment_sustainability', 'environmental-science-and-sustainability': 'agriculture_environment_sustainability',
    'mechanical-engineering': 'engineering_core', 'electrical-engineering': 'engineering_core', 'research-methods': 'science_mathematics',
    'basic-science': 'science_mathematics', 'physics-and-astronomy': 'science_mathematics', 'chemistry': 'science_mathematics',
    'math-and-logic': 'science_mathematics', 'research': 'science_mathematics', 'governance-and-society': 'humanities_social_sciences',
    'economics': 'humanities_social_sciences', 'law': 'law_legal_studies', 'history': 'humanities_social_sciences',
    'philosophy': 'humanities_social_sciences', 'music-and-art': 'arts_design_media',
}
NPTEL_FALLBACK = {
    'Aerospace Engineering': 'engineering_core', 'Agriculture': 'agriculture_environment_sustainability', 'Architecture': 'arts_design_media',
    'Atmospheric Science': 'science_mathematics', 'Automobile Engineering': 'engineering_core', 'Basic courses-Sem 1 and 2': 'science_mathematics',
    'Biotechnology': 'science_mathematics', 'Chemical Engineering': 'engineering_core', 'Chemistry and Biochemistry': 'science_mathematics',
    'Civil Engineering': 'engineering_core', 'Computer Science and  Engineering': 'computer_science_software_engineering',
    'Economics': 'humanities_social_sciences', 'Electrical Engineering': 'engineering_core', 'Electronics & Communication Engineering': 'engineering_core',
    'Energy, Climate and Sustainability': 'agriculture_environment_sustainability', 'Engineering Design': 'engineering_core',
    'Environmental Science': 'agriculture_environment_sustainability', 'General': 'personal_development_workplace_skills',
    'Humanities and Social Sciences': 'humanities_social_sciences', 'Law': 'law_legal_studies', 'Management': 'business_management_leadership',
    'Mathematics': 'science_mathematics', 'Mechanical Engineering': 'engineering_core', 'Metallurgy and Material Science': 'engineering_core',
    'Mining Engineering': 'engineering_core', 'Multidisciplinary': 'science_mathematics', 'Nanotechnology': 'science_mathematics',
    'Ocean Engineering': 'engineering_core', 'Physics': 'science_mathematics', 'Special Series': 'personal_development_workplace_skills',
    'Textile Engineering': 'engineering_core',
}
SWAYAM_CAT_FALLBACK = [
    (R(r'COMP_SCI|Computer'), 'computer_science_software_engineering'), (R(r'ENGG|ENGINEERING|AERO|CHEMICAL_COURSES|METALLURGY|MECH|ELEC|CIVIL|TEXTILE|MINING|OCEAN'), 'engineering_core'),
    (R(r'TEACHER|Education'), 'teaching_education_instructional_design'), (R(r'Management'), 'business_management_leadership'),
    (R(r'Commerce|Finance'), 'finance_accounting_banking'), (R(r'Marketing'), 'marketing_digital_marketing'), (R(r'Law'), 'law_legal_studies'),
    (R(r'Language'), 'languages_other'), (R(r'Humanities|Library'), 'humanities_social_sciences'),
    (R(r'Mathematics|Physics|Chemistry|BIO_TECH|Earth|SCHOOL'), 'science_mathematics'), (R(r'Energy|AGRI'), 'agriculture_environment_sustainability'),
    (R(r'DESIGN|ARCHI'), 'arts_design_media'),
]
MS_ROLE_DOMAIN = {
    'security-engineer': 'cybersecurity_networking', 'security-operations-analyst': 'cybersecurity_networking', 'identity-access-admin': 'cybersecurity_networking',
    'network-engineer': 'cybersecurity_networking', 'data-engineer': 'database_sql_data_engineering', 'database-administrator': 'database_sql_data_engineering',
    'data-analyst': 'data_analytics_business_intelligence', 'data-scientist': 'generative_ai_data_science', 'ai-engineer': 'artificial_intelligence_machine_learning',
    'devops-engineer': 'cloud_computing_devops', 'administrator': 'cloud_computing_devops', 'solution-architect': 'cloud_computing_devops',
    'developer': 'computer_science_software_engineering', 'functional-consultant': 'business_analysis_project_management',
    'business-analyst': 'business_analysis_project_management', 'business-user': 'personal_development_workplace_skills',
    'k-12-educator': 'teaching_education_instructional_design', 'higher-ed-educator': 'teaching_education_instructional_design',
    'school-leader': 'teaching_education_instructional_design', 'startup-founder': 'entrepreneurship_business_development',
}

GENERIC = {'business_management_leadership', 'personal_development_workplace_skills', 'communication_english_language',
           'arts_design_media', 'law_legal_studies', 'teaching_education_instructional_design', 'agriculture_environment_sustainability',
           'healthcare_administration_allied_health', 'vocational_technical_skills'}

def classify(title, fallback=None):
    t = title or ''
    for rx, dom in RULES:
        if rx.search(t):
            if dom in GENERIC and fallback in ('engineering_core', 'science_mathematics'):
                return fallback
            return dom
    return fallback or 'personal_development_workplace_skills'

def lang_code(name):
    m = {'English': 'en', 'Hindi': 'hi', 'Gujarati': 'gu', 'Tamil': 'ta', 'Punjabi': 'pa', 'Bengali': 'bn', 'Marathi': 'mr',
         'Assamese': 'as', 'Telugu': 'te', 'Kannada': 'kn', 'Malayalam': 'ml', 'Odia': 'or', 'Odiya': 'or', 'Urdu': 'ur',
         'Sanskrit': 'sa', 'Arabic': 'ar', 'Persian': 'fa', 'French': 'fr', 'German': 'de', 'Spanish': 'es'}
    return m.get((name or '').strip(), '')

ROLE_LABEL = lambda r: ' '.join(w.capitalize() for w in r.replace('k-12', 'K-12').split('-'))

# ---------------------------------------------------------------- duration parsing (only unambiguous values)
def parse_workload(w):
    """Return (duration, unit, est_hours) from Coursera workload text; ranges/ambiguous -> blanks."""
    s = (w or '').lower().strip()
    if not s:
        return '', '', ''
    m = re.fullmatch(r'(\d+)\s*hours?\s*(\d+)\s*min(ute)?s?', s)
    if m:
        mins = int(m.group(1)) * 60 + int(m.group(2))
        return mins, 'minutes', round(mins / 60, 1)
    m = re.fullmatch(r'(\d+(?:\.\d+)?)\s*(min|mins|minutes)\.?', s)
    if m:
        mins = float(m.group(1))
        return num(mins), 'minutes', round(mins / 60, 1)
    m = re.fullmatch(r'(?:approx(?:imately)?\.?\s*)?(\d+(?:\.\d+)?)\s*(h|hr|hrs|hours?)\.?(?:\s*total)?', s)
    if m:
        h = float(m.group(1))
        return num(h), 'hours', h
    m = re.match(r'^(\d+)\s*weeks?(?: of study)?[,;]?\s*(\d+(?:\.\d+)?)\s*(?:hours?|hrs?)\s*(?:/|per)\s*week', s)
    if m:
        wk, hpw = int(m.group(1)), float(m.group(2))
        return wk, 'weeks', round(wk * hpw, 1)
    m = re.match(r'^(\d+)\s*weeks?\b', s)
    if m:
        return int(m.group(1)), 'weeks', ''
    return '', '', ''

# ---------------------------------------------------------------- load link checks
def jload(p, default):
    try:
        return json.load(open(p))
    except FileNotFoundError:
        return default
coursera_lc = jload(f'{RAW}/coursera_linkcheck.json', {})
fcc_lc = jload(f'{RAW}/fcc_status.json', {})
sw_lc = jload(f'{RAW}/sw_linkcheck.json', {})
ms_lc_ok = True  # all 1,149 Microsoft Learn URLs returned HTTP 200 on 2026-10-03 (see validation report)

rows, maps = [], []
excluded_broken = []

def base(**kw):
    r = {c: '' for c in COLUMNS}
    r.update({k: v for k, v in kw.items() if k in r})
    r['record_created_date'] = TODAY
    r['record_updated_date'] = TODAY
    return r

def add(r, m):
    r = {k: (v.strip() if isinstance(v, str) else v) for k, v in r.items()}
    rows.append(r)
    m['course_id'] = r['course_id']
    maps.append({k: m.get(k, '') for k in MAP_COLUMNS})

# ================================================================ Coursera
for line in open(f'{RAW}/coursera.tsv', encoding='utf-8'):
    f = line.rstrip('\n').split('\t')
    if len(f) != 11:
        continue
    pid, slug, name, desc, doms, workload, langs, partners, instr, certs, ctype = f
    sub = doms.split(';')[0].split('/')[-1] if doms else ''
    first_dom = doms.split(';')[0].split('/')[0] if doms else ''
    lc = coursera_lc.get(slug, '')
    status, final = (lc.split('|', 1) + [''])[:2] if lc else ('', '')
    if status and status != '200':
        excluded_broken.append(('coursera', pid, f'https://www.coursera.org/learn/{slug}', status, clean(name)))
        continue
    url = 'https://www.coursera.org' + final if status == '200' and final else f'https://www.coursera.org/learn/{slug}'
    is_project = '/projects/' in url
    dur, unit, est = parse_workload(workload)
    certset = set(certs.split(';')) if certs else set()
    vstatus = 'verified' if status == '200' else ('broken_link' if status and status != '200' else 'source_listed')
    r = base(
        course_id=cid('coursera', pid), course_name=clean(name), course_description=clean(desc),
        domain=classify(name, COURSERA_FALLBACK.get(sub)), sub_domain=sub.replace('-', '_'),
        subject=first_dom.replace('-', '_'),
        course_duration=num(dur), duration_unit=unit, estimated_study_hours=num(est),
        learning_mode='online_self_paced', course_language=langs.split(';')[0] if langs else '',
        course_format='guided_project' if is_project else '',
        provider_name='Coursera', provider_type='mooc_platform', instructor_name=clean(instr),
        course_url=url, enrollment_url=url, self_paced='true',
        pricing_type='unknown',
        certificate_available=b('VerifiedCert' in certset), certificate_type='certificate_of_completion' if 'VerifiedCert' in certset else '',
        certificate_issuing_organization=(clean(partners) + '; Coursera') if partners else 'Coursera',
        examination_available='false', proctored_exam='false',
        final_project_required='true' if ctype == 'v2.capstone' else '',
        official_source_url=url, verification_status=vstatus,
        last_verified_date=TODAY if status else '', data_source='coursera_catalog_api',
        career_relevance='Part of at least one Coursera Specialization or Professional Certificate programme' if 'Specialization' in certset else '',
    )
    add(r, dict(data_source='coursera_catalog_api', provider_course_id=pid, canonical_url=url, offering_partner=clean(partners),
                source_category=doms, raw_duration_text=workload, link_check_status=status or 'not_checked',
                link_check_date=TODAY if status else '',
                notes='Coursera pricing (free audit, per-course purchase, Coursera Plus subscription, financial aid) varies by course and country; not verified per course.'))

# ================================================================ Microsoft Learn
ms = json.load(open(f'{RAW}/mslearn.json'))
active_certs = [c for c in ms['ce'] if 'retire' not in c['s'].lower()]
lp_to_cert = {}
for c in active_certs:
    for sg in c.get('sg') or []:
        if sg['type'] == 'learningPath':
            lp_to_cert.setdefault(sg['uid'], []).append(c)
exam_by_code = {}
for c in active_certs:
    for e in c['ex']:
        if isinstance(e, dict):
            exam_by_code[e['n'].upper()] = (e, c)
msu = lambda u: u.replace(' ', '%20')
LEVEL = lambda lv: (lv[0] if len(lv) == 1 else ('mixed' if lv else '')) if lv else ''

for p in ms['lp']:
    url = msu(p['u'])
    certs = lp_to_cert.get(p['uid'], [])
    rel = '; '.join(sorted({f"Study-guide path for {c['t']}" + (f" (exam {', '.join(e['n'] for e in c['ex'] if isinstance(e, dict))})" if c['ex'] else '') for c in certs}))
    roles = p.get('r') or []
    rt = p.get('rt') or {}
    dom_fb = next((MS_ROLE_DOMAIN[x] for x in roles if x in MS_ROLE_DOMAIN), None)
    r = base(
        course_id=cid('mslearn', p['uid']), course_name=clean(p['t']), course_description=clean(p['s']),
        domain=classify(p['t'], dom_fb), sub_domain='learning_path', subject='; '.join(p.get('pr') or []),
        skills_taught='; '.join(p.get('pr') or []), target_audience='; '.join(ROLE_LABEL(x) for x in roles),
        difficulty_level=LEVEL(p.get('lv') or []), course_duration=num(p.get('m')), duration_unit='minutes' if p.get('m') else '',
        estimated_study_hours=num(round(p['m'] / 60, 1)) if p.get('m') else '', learning_mode='online_self_paced',
        course_language='en', course_format='interactive_modules', syllabus_or_curriculum_url=url, course_materials_available='true',
        provider_name='Microsoft Learn', provider_type='technology_company', course_url=url, enrollment_url=url,
        enrollment_status='open', self_paced='true', pricing_type='free', course_fee='0', currency='',
        free_certificate_available='false', certificate_available='false', certificate_type='none',
        examination_available='false', proctored_exam='false', number_of_assessments='',
        relevant_job_roles='; '.join(ROLE_LABEL(x) for x in roles), career_relevance=rel,
        course_rating=num(rt.get('average')) if rt.get('count') else '', rating_source='microsoft_learn' if rt.get('count') else '',
        rating_count=num(rt.get('count')) if rt.get('count') else '',
        official_source_url=url, verification_status='verified', last_verified_date=TODAY, data_source='microsoft_learn_catalog_api')
    add(r, dict(data_source='microsoft_learn_catalog_api', provider_course_id=p['uid'], canonical_url=url, offering_partner='Microsoft',
                source_category='learningPath', raw_duration_text=f"{p.get('m')} minutes", link_check_status='200', link_check_date=TODAY,
                notes=f"{p.get('n')} modules. Completing a learning path earns a Microsoft Learn achievement, not a certificate."))

lp_titles = {re.sub(r'[^a-z0-9]+', ' ', p['t'].lower()).strip() for p in ms['lp']}
ms_course_dupes_skipped = 0
for c in ms['c']:
    if re.sub(r'[^a-z0-9]+', ' ', c['t'].lower()).strip() in lp_titles:
        ms_course_dupes_skipped += 1
        continue
    partner_led = bool(re.search(r'T\d\d$', c.get('num') or ''))
    url = msu(c['u'])
    code = re.sub(r'T\d\d$', '', (c.get('num') or '').upper())
    ex = exam_by_code.get(code)
    roles = c.get('r') or []
    dom_fb = next((MS_ROLE_DOMAIN[x] for x in roles if x in MS_ROLE_DOMAIN), None)
    r = base(
        course_id=cid('mslearn', c['uid']), course_name=clean(c['t']) + (f" ({c['num']})" if c.get('num') else ''),
        course_description=clean(c['s']), domain=classify(c['t'], dom_fb), sub_domain='instructor_led_course',
        subject='; '.join(c.get('pr') or []), skills_taught='; '.join(c.get('pr') or []),
        target_audience='; '.join(ROLE_LABEL(x) for x in roles), difficulty_level=LEVEL(c.get('lv') or []),
        course_duration=num(c.get('h')), duration_unit='hours' if c.get('h') else '', estimated_study_hours=num(c.get('h')),
        learning_mode='instructor_led' if partner_led else '', course_language='; '.join(c.get('loc') or []), syllabus_or_curriculum_url=url,
        provider_name='Microsoft Learn', provider_type='technology_company', course_url=url, enrollment_url=url,
        self_paced='false' if partner_led else '', batch_availability='Scheduled by Microsoft Learning Partners' if partner_led else '',
        pricing_type='paid' if partner_led else 'unknown', course_fee='', currency='', certificate_available='', examination_available='false', proctored_exam='false',
        relevant_job_roles='; '.join(ROLE_LABEL(x) for x in roles),
        career_relevance=(f"Course code aligns with exam {ex[0]['n']} for {ex[1]['t']}" if ex else ''),
        official_source_url=url, verification_status='verified', last_verified_date=TODAY, data_source='microsoft_learn_catalog_api')
    add(r, dict(data_source='microsoft_learn_catalog_api', provider_course_id=c['uid'], canonical_url=url, offering_partner='Microsoft Learning Partners',
                source_category='course', raw_duration_text=f"{c.get('h')} hours", link_check_status='200', link_check_date=TODAY,
                notes=('Instructor-led delivery through Microsoft Learning Partners; fee set by the partner and not recorded. Free self-paced study-guide paths exist as separate records.' if partner_led else 'Microsoft Learn course without a partner course code; delivery and pricing not stated in the catalogue.')))

for c in active_certs:
    url = msu(c['u'])
    exams = [e for e in c['ex'] if isinstance(e, dict)]
    roles = c.get('r') or []
    is_mos = c['ty'] == 'mos'
    r = base(
        course_id=cid('mslearn', c['uid']), course_name=clean(c['t']), course_description=clean(c['s']),
        domain='professional_certifications', sub_domain=f"microsoft_{c['ty'].replace('-', '_')}",
        subject='Microsoft certification', target_audience='; '.join(ROLE_LABEL(x) for x in roles),
        difficulty_level=LEVEL(c.get('lv') or []), learning_mode='online_self_paced', course_language='en',
        syllabus_or_curriculum_url=url, provider_name='Microsoft', provider_type='technology_company',
        course_url=url, enrollment_url=(exams[0]['u'] if exams else url), self_paced='true',
        pricing_type='paid', certificate_available='true', certificate_type='professional_certification',
        certificate_issuing_organization='Microsoft' if not is_mos else 'Microsoft (exams delivered by Certiport)',
        examination_available='true' if exams else '', examination_type='certification_exam' if exams else '',
        proctored_exam='true' if exams else '', exam_registration_url=(exams[0]['u'] if exams else ''),
        relevant_job_roles='; '.join(ROLE_LABEL(x) for x in roles),
        career_relevance=('Requires exam(s): ' + '; '.join(f"{e['n']} {e['t']}" for e in exams)) if exams else '',
        official_source_url=url, verification_status='verified', last_verified_date=TODAY, data_source='microsoft_learn_catalog_api')
    add(r, dict(data_source='microsoft_learn_catalog_api', provider_course_id=c['uid'], canonical_url=url, offering_partner='Microsoft',
                source_category=f"certification/{c['ty']}", link_check_status='200', link_check_date=TODAY,
                notes='Professional certification earned by passing a separate exam; exam fee varies by country and is not recorded.'))

for a in ms['as']:
    url = msu(a['u'])
    roles = a.get('r') or []
    r = base(
        course_id=cid('mslearn', a['uid']), course_name=clean(a['t']), course_description=clean(a['s']),
        domain='professional_certifications', sub_domain='microsoft_applied_skills', subject='; '.join(a.get('pr') or []),
        skills_taught='; '.join(a.get('pr') or []), target_audience='; '.join(ROLE_LABEL(x) for x in roles),
        difficulty_level=LEVEL(a.get('lv') or []), learning_mode='online_self_paced', course_language='en',
        provider_name='Microsoft', provider_type='technology_company', course_url=url, enrollment_url=url, self_paced='true',
        pricing_type='unknown', certificate_available='true', certificate_type='skills_credential', certificate_issuing_organization='Microsoft',
        examination_available='true', examination_type='lab_based_assessment', exam_registration_url=url,
        relevant_job_roles='; '.join(ROLE_LABEL(x) for x in roles),
        official_source_url=url, verification_status='verified', last_verified_date=TODAY, data_source='microsoft_learn_catalog_api')
    add(r, dict(data_source='microsoft_learn_catalog_api', provider_course_id=a['uid'], canonical_url=url, offering_partner='Microsoft',
                source_category='appliedSkills', link_check_status='200', link_check_date=TODAY,
                notes='Microsoft Applied Skills credential earned through a scenario-based assessment.'))

# ================================================================ SWAYAM (current runs) – loaded first so NPTEL archive can be enriched
sw = json.load(open(f'{RAW}/swayam.json', encoding='utf-8'))
normt = lambda s: re.sub(r'[^a-z0-9]+', ' ', re.sub(r'^noc:\s*', '', (s or '').lower())).strip()
sw_nptel_by_title = {}
for x in sw:
    if x['nc'] == 'NPTEL':
        sw_nptel_by_title.setdefault(normt(x['t']), []).append(x)
merged_sw_urls = set()
NC_TYPE = {'NPTEL': 'university_consortium', 'IGNOU': 'university', 'IIMB': 'university', 'INI': 'university',
           'AICTE': 'government_body', 'UGC': 'government_body', 'CEC': 'government_body', 'NCERT': 'government_body',
           'NIOS': 'government_body', 'NITTTR': 'government_body'}

def swayam_fields(x):
    exam = bool(x.get('xd'))
    nptel = x['nc'] == 'NPTEL'
    return dict(
        enrollment_url=x['u'], enrollment_status='open' if x.get('o') else 'closed',
        course_start_date=ist_date(x.get('sd')), course_end_date=ist_date(x.get('ed')), self_paced='false',
        batch_availability='Scheduled run on SWAYAM' + (f"; enrolment closes {ist_date(x.get('eed'))}" if x.get('eed') else ''),
        certificate_available='true' if exam else '', certificate_type='certificate_of_completion' if exam else '',
        free_certificate_available='false' if (exam and nptel) else '',
        examination_available='true' if exam else '', examination_type='final_exam' if exam else '',
        examination_mode='in_person_proctored' if (exam and nptel) else '', proctored_exam='true' if (exam and nptel) else '',
        exam_registration_url=x['u'] if exam else '',
        continuing_education_credits=num(x['cr']) if x.get('cr') else '',
        accreditation_details=(f"Listed on SWAYAM with {x['cr']} academic credits" if x.get('cr') else ''),
    )

# ================================================================ NPTEL archive
for line in open(f'{RAW}/nptel.tsv', encoding='utf-8'):
    f = line.rstrip('\n').split('\t')
    if len(f) != 12:
        continue
    pid, title, prof, inst, disc, ctype, st, noc, units, lessons, wk, syl = f
    url = f'https://nptel.ac.in/courses/{pid}'
    name = re.sub(r'^NOC:\s*', '', title).strip()
    units, lessons = int(units or 0), int(lessons or 0)
    run = None
    for cand in sw_nptel_by_title.get(normt(title), []):
        run = cand
        break
    fmt = 'video_lectures' if ctype == 'Video' else ('web_text_modules' if ctype == 'Web' else '')
    desc = (f"NPTEL {'video' if ctype == 'Video' else 'web'} course in {disc.replace('  ', ' ')} from {inst}"
            + (f", taught by {prof}" if prof else '')
            + (f"; {units} {'weeks' if wk == '1' else 'units'} and {lessons} lessons in the published outline" if units else '') + '.')
    langm = re.search(r'\bin (Hindi|Tamil|Telugu|Bengali|Marathi|Gujarati|Kannada|Malayalam)\b', name)
    r = base(
        course_id=cid('nptel', pid), course_name=name, course_description=desc,
        domain=classify(name, NPTEL_FALLBACK.get(disc)), sub_domain=slugify(disc).replace('-', '_'), subject=disc.replace('  ', ' '),
        course_duration=str(units) if (units and wk == '1') else '', duration_unit='weeks' if (units and wk == '1') else '',
        learning_mode='online_self_paced', course_language=lang_code(langm.group(1)) if langm else '', course_format=fmt,
        syllabus_or_curriculum_url=url, course_materials_available='true' if st == '200' else '',
        provider_name='NPTEL', provider_type='university_consortium', instructor_name=clean(prof),
        course_url=url, enrollment_url=url, self_paced='true', pricing_type='free', course_fee='0',
        certificate_issuing_organization=inst, official_source_url=url,
        verification_status='verified' if st == '200' else ('broken_link' if st.isdigit() else 'unverified'), last_verified_date=TODAY if st.isdigit() else '',
        data_source='nptel_course_catalog')
    if run:
        merged_sw_urls.add(run['u'])
        sf = swayam_fields(run)
        sf['self_paced'] = 'true'  # archive content is self-paced; the SWAYAM run is the scheduled certification route
        r.update({k: v for k, v in sf.items() if v != ''})
        if run.get('w'):
            r['course_duration'], r['duration_unit'] = str(run['w']), 'weeks'
        if run.get('l'):
            r['course_language'] = lang_code(run['l']) or r['course_language']
    add(r, dict(data_source='nptel_course_catalog', provider_course_id=pid, canonical_url=url, offering_partner=inst,
                source_category=disc.replace('  ', ' '), raw_duration_text=f'{units} units/{lessons} lessons',
                link_check_status=st, link_check_date=TODAY,
                notes=('Merged with current SWAYAM-NPTEL run ' + run['u'] if run else 'Archive course; certification is only available through a SWAYAM-NPTEL run.')
                + ' Description generated from catalogue metadata.'))

latest, older_runs = {}, {}
for x in sw:
    if x['u'] in merged_sw_urls:
        continue
    k = (normt(x['t']), (x.get('i') or '').lower().strip(), x['nc'], x.get('l'))
    if k not in latest or (x.get('sd') or '') > (latest[k].get('sd') or ''):
        if k in latest:
            older_runs.setdefault(k, []).append(latest[k]['u'])
        latest[k] = x
    else:
        older_runs.setdefault(k, []).append(x['u'])
swayam_runs_collapsed = sum(len(v) for v in older_runs.values())
for k, x in latest.items():
    name = clean(x['t'])
    cats = x.get('cat') or []
    fb = None
    for rx, dom in SWAYAM_CAT_FALLBACK:
        if any(rx.search(cc) for cc in cats):
            fb = dom
            break
    pid = x['u'].rstrip('/').split('/')[-2]
    lc = sw_lc.get(x['u'])
    r = base(
        course_id=cid('swayam', pid), course_name=name, course_description=clean(x.get('s')),
        domain=classify(name, fb), sub_domain=slugify(cats[0]).replace('-', '_') if cats else '',
        subject=x.get('ind') or '', target_audience=x.get('pa') or '',
        course_duration=str(x['w']) if x.get('w') else '', duration_unit='weeks' if x.get('w') else '',
        learning_mode='online_cohort', course_language=lang_code(x.get('l')),
        provider_name='SWAYAM', provider_type=NC_TYPE.get(x['nc'], 'government_body'), instructor_name=clean(x.get('i')),
        course_url=x['u'], pricing_type='free', course_fee='0',
        certificate_issuing_organization=(f"{clean(x.get('ii'))} ({x['nc']})" if x.get('ii') else x['nc']),
        official_source_url=x['u'], verification_status='verified' if lc == 200 else 'source_listed',
        last_verified_date=TODAY if lc else '', data_source='swayam_course_explorer')
    r.update(swayam_fields(x))
    add(r, dict(data_source='swayam_course_explorer', provider_course_id=pid, canonical_url=x['u'], offering_partner=clean(x.get('ii')),
                source_category='; '.join(cats), raw_duration_text=f"{x.get('w')} weeks", link_check_status=str(lc) if lc else 'not_checked',
                link_check_date=TODAY if lc else '',
                notes=f"National Coordinator {x['nc']}. SWAYAM learning is free; certificate requires the proctored exam where an exam date is listed (fee set per run, not recorded)."
                + (' Earlier runs: ' + ' '.join(older_runs[k]) if k in older_runs else '')))

# ================================================================ freeCodeCamp
intro = json.load(open(f'{SRC}/fcc_intro.json'))
cur = json.load(open(f'{SRC}/fcc_curriculum.json'))
for sb in cur['superblocks']:
    v = intro.get(sb) or {}
    t = v.get('title')
    if not t or sb == 'dev-playground':
        continue
    intro_txt = ' '.join(v.get('intro', [])) if isinstance(v.get('intro'), list) else ''
    if 'placeholder' in intro_txt.lower() or 'to be added' in intro_txt.lower():
        continue
    st = fcc_lc.get(sb, fcc_lc.get('_default'))
    if st != 200:
        continue
    url = f'https://www.freecodecamp.org/learn/{sb}/'
    is_cert = 'Certification' in t and 'Legacy' not in t
    beta = '(Beta)' in t
    r = base(
        course_id=cid('freecodecamp', sb), course_name=t, course_description=clean(intro_txt)[:400],
        domain=classify(t, 'computer_science_software_engineering'), sub_domain='freecodecamp_curriculum',
        learning_mode='online_self_paced', course_language='en', course_format='interactive_coding',
        syllabus_or_curriculum_url=url, course_materials_available='true',
        provider_name='freeCodeCamp', provider_type='nonprofit', course_url=url, enrollment_url=url, enrollment_status='open',
        self_paced='true', pricing_type='free', course_fee='0',
        certificate_available='true' if is_cert else '', free_certificate_available='true' if is_cert else '',
        certificate_type='certificate_of_completion' if is_cert else '', certificate_fee='0' if is_cert else '',
        certificate_issuing_organization='freeCodeCamp' if is_cert else '',
        final_project_required='true' if (is_cert and re.search(r'required projects', intro_txt, re.I)) else '',
        portfolio_value='high' if (is_cert and re.search(r'projects', intro_txt, re.I)) else '',
        official_source_url=url, verification_status='verified', last_verified_date=TODAY,
        data_source='freecodecamp_github_curriculum')
    add(r, dict(data_source='freecodecamp_github_curriculum', provider_course_id=sb, canonical_url=url, offering_partner='freeCodeCamp',
                source_category='superblock', link_check_status='200', link_check_date=TODAY,
                notes=('Beta curriculum. ' if beta else '') + ('Legacy curriculum retained on freeCodeCamp. ' if 'Legacy' in t else '')))

# ================================================================ dedupe + slugs
seen_id, seen_url, final, final_maps = set(), set(), [], []
dup_id = dup_url = 0
for r, m in zip(rows, maps):
    u = r['course_url'].rstrip('/').lower()
    if r['course_id'] in seen_id:
        dup_id += 1; continue
    if u in seen_url:
        dup_url += 1; continue
    seen_id.add(r['course_id']); seen_url.add(u)
    final.append(r); final_maps.append(m)

slugs = {}
PCODE = {'Coursera': 'coursera', 'Microsoft Learn': 'mslearn', 'Microsoft': 'microsoft', 'NPTEL': 'nptel', 'SWAYAM': 'swayam', 'freeCodeCamp': 'fcc'}
for r in final:
    s = slugify(r['course_name'])
    if s in slugs:
        s2 = f"{s}-{PCODE.get(r['provider_name'], 'x')}"
        n = 2
        while s2 in slugs:
            s2 = f"{s}-{PCODE.get(r['provider_name'], 'x')}-{n}"; n += 1
        s = s2
    slugs[s] = 1
    r['course_slug'] = s

with open(f'{OUT}/course_platform_database.csv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=COLUMNS, quoting=csv.QUOTE_MINIMAL, lineterminator='\n')
    w.writeheader(); w.writerows(final)
with open(f'{OUT}/course_source_map.csv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.DictWriter(fh, fieldnames=MAP_COLUMNS, quoting=csv.QUOTE_MINIMAL, lineterminator='\n')
    w.writeheader(); w.writerows(final_maps)
print('rows', len(final), 'dup_id_removed', dup_id, 'dup_url_removed', dup_url, 'swayam_merged_into_nptel', len(merged_sw_urls))
with open(f'{OUT}/excluded_broken_links.csv', 'w', newline='', encoding='utf-8') as fh:
    w = csv.writer(fh, lineterminator='\n'); w.writerow(['data_source', 'provider_course_id', 'url', 'http_status', 'course_name']); w.writerows(excluded_broken)
json.dump({'broken_links_excluded': len(excluded_broken), 'ms_courses_duplicating_paths_skipped': ms_course_dupes_skipped, 'swayam_runs_collapsed': swayam_runs_collapsed, 'dup_id_removed': dup_id, 'dup_url_removed': dup_url, 'swayam_merged_into_nptel': len(merged_sw_urls),
           'retired_ms_certs_excluded': len(ms['ce']) - len(active_certs)}, open(f'{OUT}/.build_stats.json', 'w'))
